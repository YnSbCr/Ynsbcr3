export interface PriceQuote {
  symbol: string;
  price: number;
  currency: string;
  source: string;
  observedAt: Date;
  change24h?: number;
  changePercent24h?: number;
}

export interface ConvertedPriceQuote extends PriceQuote {
  priceUSD?: number;
  priceTRY?: number;
}

export interface PriceRequest {
  symbol: string;
  market?: string;
  type?: 'stock' | 'crypto' | 'commodity' | 'forex' | 'etf' | 'fund';
  quoteCurrency?: string;
}

export interface IPriceProvider {
  name: string;
  supports(asset: PriceRequest): boolean;
  getQuote(request: PriceRequest): Promise<PriceQuote>;
  getMultipleQuotes?(requests: PriceRequest[]): Promise<PriceQuote[]>;
  getRateLimit(): { requestsPerMinute: number; requestsPerDay: number };
}

export interface ExchangeRate {
  from: string;
  to: string;
  rate: number;
  source: string;
  observedAt: Date;
}

export interface PriceServiceConfig {
  providers: {
    stocks: string[];
    crypto: string[];
    commodities: string[];
    forex: string[];
  };
  cache: {
    stockTTL: number;
    cryptoTTL: number;
    commodityTTL: number;
    forexTTL: number;
  };
  fallbackEnabled: boolean;
}