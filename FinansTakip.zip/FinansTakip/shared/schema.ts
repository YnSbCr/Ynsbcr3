import { sql } from "drizzle-orm";
import { pgTable, text, varchar, decimal, integer, timestamp, jsonb, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  preferredCurrency: text("preferred_currency").notNull().default("TRY"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const assetCategories = pgTable("asset_categories", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  type: text("type").notNull(), // 'stocks', 'crypto', 'commodities', 'funds', 'etf'
  market: text("market"), // 'US', 'BIST', 'global'
  icon: text("icon"),
});

export const assets = pgTable("assets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  symbol: text("symbol").notNull(),
  name: text("name").notNull(),
  categoryId: varchar("category_id").references(() => assetCategories.id),
  currentPrice: decimal("current_price", { precision: 15, scale: 4 }),
  currency: text("currency").notNull().default("USD"),
  lastUpdated: timestamp("last_updated").defaultNow(),
  metadata: jsonb("metadata"), // Additional info like market cap, volume, etc.
});

export const portfolioAssets = pgTable("portfolio_assets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  assetId: varchar("asset_id").references(() => assets.id).notNull(),
  quantity: decimal("quantity", { precision: 15, scale: 8 }).notNull(),
  averagePurchasePrice: decimal("average_purchase_price", { precision: 15, scale: 4 }).notNull(),
  purchaseCurrency: text("purchase_currency").notNull().default("USD"), // "USD" or "TRY"
  totalInvested: decimal("total_invested", { precision: 15, scale: 2 }).notNull(),
  purchaseDate: timestamp("purchase_date"),
  exchangeRate: decimal("exchange_rate", { precision: 10, scale: 4 }), // USD/TRY exchange rate
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const transactions = pgTable("transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  assetId: varchar("asset_id").references(() => assets.id).notNull(),
  type: text("type").notNull(), // 'buy', 'sell'
  quantity: decimal("quantity", { precision: 15, scale: 8 }).notNull(),
  price: decimal("price", { precision: 15, scale: 4 }).notNull(),
  totalAmount: decimal("total_amount", { precision: 15, scale: 2 }).notNull(),
  fees: decimal("fees", { precision: 15, scale: 2 }).default("0"),
  currency: text("currency").notNull(),
  exchangeRate: decimal("exchange_rate", { precision: 10, scale: 4 }), // USD/TRY exchange rate
  date: timestamp("date").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const incomeRecords = pgTable("income_records", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  type: text("type").notNull(), // 'salary', 'dividend', 'bonus', 'other'
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  currency: text("currency").notNull().default("TRY"),
  description: text("description"),
  date: timestamp("date").notNull(),
  isRecurring: boolean("is_recurring").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const expenseRecords = pgTable("expense_records", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  type: text("type").notNull(), // 'kmh_loan', 'credit_card', 'living', 'other'
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  currency: text("currency").notNull().default("TRY"),
  description: text("description"),
  interestRate: decimal("interest_rate", { precision: 5, scale: 2 }), // for loans/credit cards
  installments: integer("installments"), // number of remaining installments
  dueDate: timestamp("due_date"),
  date: timestamp("date").notNull(),
  isRecurring: boolean("is_recurring").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Multi-platform crypto trading tables
export const platforms = pgTable("platforms", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(), // "Binance", "Midas", etc.
  type: text("type").notNull(), // 'cex', 'broker', 'dex'
  metadata: jsonb("metadata"), // API endpoints, fees, etc.
  createdAt: timestamp("created_at").defaultNow(),
});

export const platformAccounts = pgTable("platform_accounts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  platformId: varchar("platform_id").references(() => platforms.id).notNull(),
  accountRef: text("account_ref"), // Account name or reference
  baseReportingCurrency: text("base_reporting_currency").notNull().default("TRY"),
  metadata: jsonb("metadata"), // API keys, settings, etc.
  createdAt: timestamp("created_at").defaultNow(),
});

export const currencies = pgTable("currencies", {
  code: text("code").primaryKey(), // TRY, USD, USDT, BTC, etc.
  type: text("type").notNull(), // 'fiat', 'crypto'
  decimals: integer("decimals").notNull().default(8),
  metadata: jsonb("metadata"), // full name, etc.
});

export const markets = pgTable("markets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  platformId: varchar("platform_id").references(() => platforms.id).notNull(),
  baseAssetId: varchar("base_asset_id").references(() => assets.id).notNull(),
  quoteCurrency: text("quote_currency").references(() => currencies.code).notNull(),
  platformSymbol: text("platform_symbol").notNull(), // "SOLUSDT", "SOL/TRY", etc.
  minQuantity: decimal("min_quantity", { precision: 18, scale: 8 }),
  stepSize: decimal("step_size", { precision: 18, scale: 8 }),
  tickSize: decimal("tick_size", { precision: 18, scale: 8 }),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const trades = pgTable("trades", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  platformAccountId: varchar("platform_account_id").references(() => platformAccounts.id).notNull(),
  marketId: varchar("market_id").references(() => markets.id).notNull(),
  side: text("side").notNull(), // 'buy', 'sell'
  quantityBase: decimal("quantity_base", { precision: 18, scale: 8 }).notNull(),
  priceQuote: decimal("price_quote", { precision: 18, scale: 8 }).notNull(),
  feeAmount: decimal("fee_amount", { precision: 18, scale: 8 }).default("0"),
  feeCurrency: text("fee_currency").references(() => currencies.code),
  totalQuote: decimal("total_quote", { precision: 18, scale: 8 }).notNull(),
  tradedAt: timestamp("traded_at").notNull(),
  externalRef: text("external_ref"), // Platform's trade ID
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const fxRates = pgTable("fx_rates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  baseCurrency: text("base_currency").references(() => currencies.code).notNull(),
  quoteCurrency: text("quote_currency").references(() => currencies.code).notNull(),
  rate: decimal("rate", { precision: 18, scale: 8 }).notNull(),
  source: text("source").notNull(), // 'manual', 'api', etc.
  observedAt: timestamp("observed_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const priceTicks = pgTable("price_ticks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  assetId: varchar("asset_id").references(() => assets.id).notNull(),
  quoteCurrency: text("quote_currency").references(() => currencies.code).notNull(),
  price: decimal("price", { precision: 18, scale: 8 }).notNull(),
  source: text("source").notNull(), // 'binance', 'midas', etc.
  observedAt: timestamp("observed_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertAssetCategorySchema = createInsertSchema(assetCategories).omit({
  id: true,
});

export const insertAssetSchema = createInsertSchema(assets).omit({
  id: true,
  lastUpdated: true,
});

export const insertPortfolioAssetSchema = createInsertSchema(portfolioAssets).omit({
  id: true,
  userId: true, // We'll add this server-side
  createdAt: true,
  updatedAt: true,
}).extend({
  purchaseDate: z.string().optional().transform((val) => val ? new Date(val) : undefined),
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
});

export const insertIncomeRecordSchema = createInsertSchema(incomeRecords).omit({
  id: true,
  createdAt: true,
});

export const insertExpenseRecordSchema = createInsertSchema(expenseRecords).omit({
  id: true,
  createdAt: true,
});

// Multi-platform trading insert schemas
export const insertPlatformSchema = createInsertSchema(platforms).omit({
  id: true,
  createdAt: true,
});

export const insertPlatformAccountSchema = createInsertSchema(platformAccounts).omit({
  id: true,
  createdAt: true,
});

export const insertCurrencySchema = createInsertSchema(currencies);

export const insertMarketSchema = createInsertSchema(markets).omit({
  id: true,
  createdAt: true,
});

export const insertTradeSchema = createInsertSchema(trades).omit({
  id: true,
  createdAt: true,
}).extend({
  tradedAt: z.string().transform((val) => new Date(val)),
});

export const insertFxRateSchema = createInsertSchema(fxRates).omit({
  id: true,
  createdAt: true,
}).extend({
  observedAt: z.string().transform((val) => new Date(val)),
});

export const insertPriceTickSchema = createInsertSchema(priceTicks).omit({
  id: true,
  createdAt: true,
}).extend({
  observedAt: z.string().transform((val) => new Date(val)),
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type AssetCategory = typeof assetCategories.$inferSelect;
export type InsertAssetCategory = z.infer<typeof insertAssetCategorySchema>;

export type Asset = typeof assets.$inferSelect;
export type InsertAsset = z.infer<typeof insertAssetSchema>;

export type PortfolioAsset = typeof portfolioAssets.$inferSelect;
export type InsertPortfolioAsset = z.infer<typeof insertPortfolioAssetSchema>;

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

export type IncomeRecord = typeof incomeRecords.$inferSelect;
export type InsertIncomeRecord = z.infer<typeof insertIncomeRecordSchema>;

export type ExpenseRecord = typeof expenseRecords.$inferSelect;
export type InsertExpenseRecord = z.infer<typeof insertExpenseRecordSchema>;

// Multi-platform trading types
export type Platform = typeof platforms.$inferSelect;
export type InsertPlatform = z.infer<typeof insertPlatformSchema>;

export type PlatformAccount = typeof platformAccounts.$inferSelect;
export type InsertPlatformAccount = z.infer<typeof insertPlatformAccountSchema>;

export type Currency = typeof currencies.$inferSelect;
export type InsertCurrency = z.infer<typeof insertCurrencySchema>;

export type Market = typeof markets.$inferSelect;
export type InsertMarket = z.infer<typeof insertMarketSchema>;

export type Trade = typeof trades.$inferSelect;
export type InsertTrade = z.infer<typeof insertTradeSchema>;

export type FxRate = typeof fxRates.$inferSelect;
export type InsertFxRate = z.infer<typeof insertFxRateSchema>;

export type PriceTick = typeof priceTicks.$inferSelect;
export type InsertPriceTick = z.infer<typeof insertPriceTickSchema>;
