import { BasePriceProvider } from './base-provider';
import type { PriceRequest, PriceQuote } from "@shared/types/price";

interface ExchangeRateResponse {
  rates: Record<string, number>;
  base: string;
  date: string;
}

interface TCMBResponse {
  [date: string]: {
    USD: {
      Buying: number;
      Selling: number;
    };
  };
}

export class ExchangeRateProvider extends BasePriceProvider {
  name = 'ExchangeRate';
  private exchangeRateHost = 'https://api.exchangerate.host';
  private tcmbUrl = 'https://evds2.tcmb.gov.tr/service/evds/latest?items=TP.DK.USD.A.YTL';

  supports(asset: PriceRequest): boolean {
    return asset.type === 'forex' && (
      asset.symbol === 'USDTRY' || 
      asset.symbol === 'USD/TRY' ||
      asset.symbol === 'USD_TRY'
    );
  }

  async getQuote(request: PriceRequest): Promise<PriceQuote> {
    // Skip TCMB (requires API key), use exchangerate.host directly
    // TODO: Add TCMB with proper API key management later
    return await this.getExchangeRateHostRate();
  }

  private async getTCMBRate(): Promise<PriceQuote> {
    try {
      const response = await this.fetchWithTimeout(this.tcmbUrl);
      
      if (!response.ok) {
        throw new Error(`TCMB API error: ${response.status}`);
      }

      const data: TCMBResponse = await response.json();
      const dates = Object.keys(data);
      
      if (dates.length === 0) {
        throw new Error('No TCMB data available');
      }

      const latestDate = dates[dates.length - 1];
      const usdData = data[latestDate]?.USD;
      
      if (!usdData) {
        throw new Error('USD rate not found in TCMB data');
      }

      // Use selling rate (official rate for currency conversion)
      const rate = usdData.Selling;
      
      return {
        symbol: 'USDTRY',
        price: rate,
        currency: 'TRY',
        source: 'TCMB',
        observedAt: new Date(),
      };
    } catch (error) {
      console.error('TCMB provider error:', error);
      throw error;
    }
  }

  private async getExchangeRateHostRate(): Promise<PriceQuote> {
    const url = `${this.exchangeRateHost}/latest?base=USD&symbols=TRY`;
    
    try {
      const response = await this.fetchWithTimeout(url);
      
      if (!response.ok) {
        throw new Error(`ExchangeRate.host API error: ${response.status}`);
      }

      const data: ExchangeRateResponse = await response.json();
      
      if (!data.rates?.TRY) {
        throw new Error('TRY rate not found');
      }

      return {
        symbol: 'USDTRY',
        price: data.rates.TRY,
        currency: 'TRY',
        source: 'ExchangeRate.host',
        observedAt: new Date(),
      };
    } catch (error) {
      console.error('ExchangeRate.host provider error:', error);
      throw error;
    }
  }

  getRateLimit(): { requestsPerMinute: number; requestsPerDay: number } {
    return { requestsPerMinute: 60, requestsPerDay: 1000 };
  }
}