import { BasePriceProvider } from './base-provider';
import type { PriceRequest, PriceQuote } from "@shared/types/price";

interface YahooFinanceResponse {
  chart: {
    result: Array<{
      meta: {
        regularMarketPrice: number;
        symbol: string;
        currency: string;
        previousClose: number;
      };
      timestamp: number[];
      indicators: {
        quote: Array<{
          close: number[];
        }>;
      };
    }>;
  };
}

export class YahooFinanceProvider extends BasePriceProvider {
  name = 'YahooFinance';
  private baseUrl = 'https://query1.finance.yahoo.com/v8/finance/chart';

  supports(asset: PriceRequest): boolean {
    return asset.type === 'stock' || asset.type === 'etf';
  }

  async getQuote(request: PriceRequest): Promise<PriceQuote> {
    const symbol = this.formatSymbol(request.symbol, request.market);
    const url = `${this.baseUrl}/${symbol}?interval=1d&range=1d`;
    
    try {
      const response = await this.fetchWithTimeout(url);
      
      if (!response.ok) {
        throw new Error(`Yahoo Finance API error: ${response.status} ${response.statusText}`);
      }

      const data: YahooFinanceResponse = await response.json();
      
      if (!this.validateResponse(data) || !data.chart?.result?.[0]) {
        throw new Error(`No data found for ${request.symbol}`);
      }

      const result = data.chart.result[0];
      const currentPrice = result.meta.regularMarketPrice;
      const previousClose = result.meta.previousClose;
      
      if (!currentPrice) {
        throw new Error(`No price data available for ${request.symbol}`);
      }

      const change = currentPrice - previousClose;
      const changePercent = previousClose > 0 ? (change / previousClose) * 100 : 0;

      return {
        symbol: request.symbol,
        price: currentPrice,
        currency: result.meta.currency || 'USD',
        source: this.name,
        observedAt: new Date(),
        change24h: change,
        changePercent24h: changePercent,
      };
    } catch (error) {
      console.error(`Yahoo Finance provider error for ${request.symbol}:`, error);
      throw error;
    }
  }

  protected formatSymbol(symbol: string, market?: string): string {
    // Format symbols for different markets
    if (market === 'BIST' || symbol.endsWith('.IS')) {
      // BIST symbols use .IS suffix
      return symbol.endsWith('.IS') ? symbol : `${symbol}.IS`;
    }
    
    // US stocks use plain symbols
    return symbol.toUpperCase();
  }

  getRateLimit(): { requestsPerMinute: number; requestsPerDay: number } {
    return { requestsPerMinute: 120, requestsPerDay: 10000 }; // Yahoo Finance is more generous
  }
}