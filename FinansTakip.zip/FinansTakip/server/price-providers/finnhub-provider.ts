import { BasePriceProvider } from './base-provider';
import type { PriceRequest, PriceQuote } from "@shared/types/price";

interface FinnhubQuoteResponse {
  c: number; // current price
  d: number; // change
  dp: number; // percent change
  h: number; // high price of the day
  l: number; // low price of the day
  o: number; // open price of the day
  pc: number; // previous close price
  t: number; // timestamp
}

export class FinnhubProvider extends BasePriceProvider {
  name = 'Finnhub';
  private baseUrl = 'https://finnhub.io/api/v1';
  private apiKey: string;
  private isEnabled: boolean;

  constructor() {
    super();
    this.apiKey = process.env.FINNHUB_API_KEY || '';
    this.isEnabled = !!this.apiKey;
    
    if (!this.isEnabled) {
      console.warn('Finnhub provider disabled: FINNHUB_API_KEY not provided');
    }
  }

  supports(asset: PriceRequest): boolean {
    return this.isEnabled && (asset.type === 'stock' || asset.type === 'etf');
  }

  async getQuote(request: PriceRequest): Promise<PriceQuote> {
    const symbol = this.formatSymbol(request.symbol, request.market);
    const url = `${this.baseUrl}/quote?symbol=${symbol}&token=${this.apiKey}`;
    
    try {
      const response = await this.fetchWithTimeout(url);
      
      if (!response.ok) {
        throw new Error(`Finnhub API error: ${response.status} ${response.statusText}`);
      }

      const data: FinnhubQuoteResponse = await response.json();
      
      if (!this.validateResponse(data) || data.c === 0) {
        throw new Error(`No data found for ${request.symbol}`);
      }

      return {
        symbol: request.symbol,
        price: data.c,
        currency: 'USD', // Finnhub returns USD prices
        source: this.name,
        observedAt: new Date(data.t * 1000),
        change24h: data.d,
        changePercent24h: data.dp,
      };
    } catch (error) {
      console.error(`Finnhub provider error for ${request.symbol}:`, error);
      throw error;
    }
  }

  protected formatSymbol(symbol: string, market?: string): string {
    // Format symbols for different markets
    if (market === 'BIST' || symbol.endsWith('.IS')) {
      // BIST symbols should end with .IS for Finnhub
      return symbol.endsWith('.IS') ? symbol : `${symbol}.IS`;
    }
    
    // US stocks use plain symbols
    return symbol.toUpperCase();
  }

  getRateLimit(): { requestsPerMinute: number; requestsPerDay: number } {
    return { requestsPerMinute: 60, requestsPerDay: 1000 }; // Finnhub free tier limits
  }
}