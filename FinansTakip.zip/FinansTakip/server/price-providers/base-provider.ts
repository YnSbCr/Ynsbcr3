import type { IPriceProvider, PriceRequest, PriceQuote } from "@shared/types/price";

export abstract class BasePriceProvider implements IPriceProvider {
  abstract name: string;
  
  abstract supports(asset: PriceRequest): boolean;
  abstract getQuote(request: PriceRequest): Promise<PriceQuote>;
  abstract getRateLimit(): { requestsPerMinute: number; requestsPerDay: number };

  protected async fetchWithTimeout(url: string, options: RequestInit = {}, timeoutMs = 5000): Promise<Response> {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
    
    try {
      const response = await fetch(url, {
        ...options,
        signal: controller.signal,
        headers: {
          'User-Agent': 'Portfolio-Tracker/1.0',
          ...options.headers,
        },
      });
      clearTimeout(timeoutId);
      return response;
    } catch (error) {
      clearTimeout(timeoutId);
      throw error;
    }
  }

  protected formatSymbol(symbol: string, market?: string): string {
    // Override in specific providers for market-specific formatting
    return symbol.toUpperCase();
  }

  protected validateResponse(data: any): boolean {
    return data && typeof data === 'object';
  }
}