import { BasePriceProvider } from './base-provider';
import type { PriceRequest, PriceQuote } from "@shared/types/price";

interface CoinGeckoResponse {
  [coinId: string]: {
    usd: number;
    try: number;
    usd_24h_change?: number;
  };
}

export class CoinGeckoProvider extends BasePriceProvider {
  name = 'CoinGecko';
  private baseUrl = 'https://api.coingecko.com/api/v3';
  
  // Mapping of common crypto symbols to CoinGecko IDs
  private symbolToIdMap: Record<string, string> = {
    'BTC': 'bitcoin',
    'ETH': 'ethereum',
    'ADA': 'cardano',
    'XRP': 'ripple',
    'DOT': 'polkadot',
    'AVAX': 'avalanche-2',
    'MATIC': 'matic-network',
    'SOL': 'solana',
    'DOGE': 'dogecoin',
    'LTC': 'litecoin',
    'BNB': 'binancecoin',
    'UNI': 'uniswap',
    'LINK': 'chainlink',
  };

  supports(asset: PriceRequest): boolean {
    return asset.type === 'crypto' && this.symbolToIdMap[asset.symbol] !== undefined;
  }

  async getQuote(request: PriceRequest): Promise<PriceQuote> {
    const coinId = this.symbolToIdMap[request.symbol];
    if (!coinId) {
      throw new Error(`Unsupported crypto symbol: ${request.symbol}`);
    }

    const quoteCurrency = request.quoteCurrency?.toLowerCase() || 'usd';
    const supportedCurrencies = ['usd', 'try'];
    const currencies = supportedCurrencies.join(',');
    
    const url = `${this.baseUrl}/simple/price?ids=${coinId}&vs_currencies=${currencies}&include_24hr_change=true`;
    
    try {
      const response = await this.fetchWithTimeout(url);
      
      if (!response.ok) {
        throw new Error(`CoinGecko API error: ${response.status} ${response.statusText}`);
      }

      const data: CoinGeckoResponse = await response.json();
      
      if (!this.validateResponse(data) || !data[coinId]) {
        throw new Error(`No data found for ${request.symbol}`);
      }

      const coinData = data[coinId];
      const price = quoteCurrency === 'try' ? coinData.try : coinData.usd;
      const currency = quoteCurrency === 'try' ? 'TRY' : 'USD';
      
      if (price === undefined) {
        throw new Error(`Price not available in ${currency} for ${request.symbol}`);
      }

      return {
        symbol: request.symbol,
        price,
        currency,
        source: this.name,
        observedAt: new Date(),
        change24h: coinData.usd_24h_change ? (price * coinData.usd_24h_change / 100) : undefined,
        changePercent24h: coinData.usd_24h_change,
      };
    } catch (error) {
      console.error(`CoinGecko provider error for ${request.symbol}:`, error);
      throw error;
    }
  }

  async getMultipleQuotes(requests: PriceRequest[]): Promise<PriceQuote[]> {
    const coinIds = requests
      .filter(req => this.supports(req))
      .map(req => this.symbolToIdMap[req.symbol])
      .filter(Boolean);
    
    if (coinIds.length === 0) {
      return [];
    }

    const currencies = 'usd,try';
    const url = `${this.baseUrl}/simple/price?ids=${coinIds.join(',')}&vs_currencies=${currencies}&include_24hr_change=true`;
    
    try {
      const response = await this.fetchWithTimeout(url);
      
      if (!response.ok) {
        throw new Error(`CoinGecko API error: ${response.status} ${response.statusText}`);
      }

      const data: CoinGeckoResponse = await response.json();
      
      return requests
        .filter(req => this.supports(req))
        .map(req => {
          const coinId = this.symbolToIdMap[req.symbol];
          const coinData = data[coinId];
          
          if (!coinData) {
            throw new Error(`No data found for ${req.symbol}`);
          }

          const quoteCurrency = req.quoteCurrency?.toLowerCase() || 'usd';
          const price = quoteCurrency === 'try' ? coinData.try : coinData.usd;
          const currency = quoteCurrency === 'try' ? 'TRY' : 'USD';
          
          return {
            symbol: req.symbol,
            price,
            currency,
            source: this.name,
            observedAt: new Date(),
            change24h: coinData.usd_24h_change ? (price * coinData.usd_24h_change / 100) : undefined,
            changePercent24h: coinData.usd_24h_change,
          };
        });
    } catch (error) {
      console.error('CoinGecko bulk provider error:', error);
      throw error;
    }
  }

  getRateLimit(): { requestsPerMinute: number; requestsPerDay: number } {
    return { requestsPerMinute: 30, requestsPerDay: 1000 }; // CoinGecko free tier limits
  }
}