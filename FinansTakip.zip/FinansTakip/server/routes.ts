import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { financialAPI } from "./services/financial-api";
import { currencyConverter } from "./services/currency-converter";
import { priceService } from "./services/price-service";
import { insertPortfolioAssetSchema, insertTransactionSchema, insertIncomeRecordSchema, insertExpenseRecordSchema } from "@shared/schema";
import type { PriceRequest } from "@shared/types/price";

export async function registerRoutes(app: Express): Promise<Server> {
  const DEFAULT_USER_ID = "default-user";

  // Asset Categories
  app.get("/api/asset-categories", async (req, res) => {
    try {
      const categories = await storage.getAssetCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch asset categories" });
    }
  });

  // Assets
  app.get("/api/assets", async (req, res) => {
    try {
      const { categoryId } = req.query;
      const assets = categoryId 
        ? await storage.getAssetsByCategory(categoryId as string)
        : await storage.getAssets();
      res.json(assets);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch assets" });
    }
  });

  app.get("/api/assets/search", async (req, res) => {
    try {
      const { q } = req.query;
      if (!q || typeof q !== "string") {
        return res.status(400).json({ error: "Query parameter 'q' is required" });
      }

      const searchResults = await financialAPI.searchAssets(q);
      res.json(searchResults);
    } catch (error) {
      res.status(500).json({ error: "Failed to search assets" });
    }
  });

  app.get("/api/assets/:symbol/price", async (req, res) => {
    try {
      const { symbol } = req.params;
      const { quote = 'USD', market } = req.query;
      
      // Determine asset type and market from symbol and query params
      let assetType: PriceRequest['type'] = 'stock';
      let detectedMarket: string | undefined;
      
      if (symbol.match(/^(BTC|ETH|ADA|XRP|DOT|AVAX|MATIC|SOL|DOGE|LTC|BNB|UNI|LINK)$/i)) {
        assetType = 'crypto';
      } else if (symbol === 'USDTRY' || symbol === 'USD_TRY') {
        assetType = 'forex';
      } else if (symbol.endsWith('.IS') || market === 'BIST') {
        // BIST stocks: explicit .IS suffix or market parameter
        assetType = 'stock';
        detectedMarket = 'BIST';
      }
      
      const request: PriceRequest = {
        symbol: symbol.toUpperCase(),
        type: assetType,
        market: detectedMarket,
        quoteCurrency: quote as string
      };
      
      const priceData = await priceService.getQuote(request);
      res.json(priceData);
    } catch (error) {
      console.error('Price fetch error:', error);
      res.status(500).json({ error: "Failed to fetch asset price" });
    }
  });

  // Bulk Price API
  app.get("/api/prices", async (req, res) => {
    try {
      const { symbols, quote = 'USD', type = 'auto', market } = req.query;
      
      if (!symbols || typeof symbols !== 'string') {
        return res.status(400).json({ error: "symbols parameter is required" });
      }
      
      const symbolList = symbols.split(',').map(s => s.trim().toUpperCase());
      const requests: PriceRequest[] = symbolList.map(symbol => {
        // Auto-detect asset type and market
        let assetType: PriceRequest['type'] = 'stock';
        let detectedMarket: string | undefined;
        
        if (symbol.match(/^(BTC|ETH|ADA|XRP|DOT|AVAX|MATIC|SOL|DOGE|LTC|BNB|UNI|LINK)$/i)) {
          assetType = 'crypto';
        } else if (symbol === 'USDTRY' || symbol === 'USD_TRY') {
          assetType = 'forex';
        } else if (symbol.endsWith('.IS') || market === 'BIST') {
          // BIST stocks: explicit .IS suffix or market parameter
          assetType = 'stock';
          detectedMarket = 'BIST';
        }
        
        return {
          symbol,
          type: type === 'auto' ? assetType : type as PriceRequest['type'],
          market: detectedMarket,
          quoteCurrency: quote as string
        };
      });
      
      const prices = await priceService.getMultipleQuotes(requests);
      res.json({ prices, count: prices.length });
    } catch (error) {
      console.error('Bulk price fetch error:', error);
      res.status(500).json({ error: "Failed to fetch prices" });
    }
  });

  // Exchange Rate API
  app.get("/api/fx/:pair", async (req, res) => {
    try {
      const { pair } = req.params;
      
      if (pair.toUpperCase() === 'USDTRY') {
        try {
          const exchangeRate = await priceService.getExchangeRate('USD', 'TRY');
          res.json(exchangeRate);
        } catch (error) {
          // Fallback to static rate if all providers fail
          console.warn('Exchange rate providers failed, using fallback rate:', error);
          res.json({
            baseCurrency: 'USD',
            quoteCurrency: 'TRY', 
            rate: 32.50, // Static fallback rate
            source: 'fallback',
            observedAt: new Date().toISOString()
          });
        }
      } else {
        res.status(400).json({ error: "Only USD/TRY exchange rate is currently supported" });
      }
    } catch (error) {
      console.error('Exchange rate fetch error:', error);
      res.status(500).json({ error: "Failed to fetch exchange rate" });
    }
  });

  // Portfolio
  app.get("/api/portfolio", async (req, res) => {
    try {
      const portfolioAssets = await storage.getPortfolioAssets(DEFAULT_USER_ID);
      const assetsWithDetails = await Promise.all(
        portfolioAssets.map(async (pa) => {
          const asset = await storage.getAssets().then(assets => 
            assets.find(a => a.id === pa.assetId)
          );
          const category = asset ? await storage.getAssetCategories().then(cats =>
            cats.find(c => c.id === asset.categoryId)
          ) : null;

          const currentValue = asset && asset.currentPrice 
            ? parseFloat(pa.quantity) * parseFloat(asset.currentPrice)
            : 0;
          
          const totalInvested = parseFloat(pa.totalInvested);
          const profitLoss = currentValue - totalInvested;
          const profitLossPercent = totalInvested > 0 ? (profitLoss / totalInvested) * 100 : 0;

          return {
            ...pa,
            asset,
            category,
            currentValue,
            profitLoss,
            profitLossPercent
          };
        })
      );

      // Calculate portfolio summary
      const totalValue = assetsWithDetails.reduce((sum, item) => sum + item.currentValue, 0);
      const totalInvested = assetsWithDetails.reduce((sum, item) => sum + parseFloat(item.totalInvested), 0);
      const totalProfitLoss = totalValue - totalInvested;
      const totalProfitLossPercent = totalInvested > 0 ? (totalProfitLoss / totalInvested) * 100 : 0;

      res.json({
        summary: {
          totalValue,
          totalInvested,
          totalProfitLoss,
          totalProfitLossPercent,
          currency: "TRY"
        },
        assets: assetsWithDetails
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch portfolio" });
    }
  });

  app.post("/api/portfolio/assets", async (req, res) => {
    try {
      console.log("POST /api/portfolio/assets - Request body:", JSON.stringify(req.body, null, 2));
      const data = insertPortfolioAssetSchema.parse(req.body);
      console.log("POST /api/portfolio/assets - Parsed data:", JSON.stringify(data, null, 2));
      const portfolioAsset = await storage.createPortfolioAsset({
        userId: DEFAULT_USER_ID,
        assetId: data.assetId,
        quantity: data.quantity,
        averagePurchasePrice: data.averagePurchasePrice,
        totalInvested: data.totalInvested,
        purchaseDate: data.purchaseDate,
        exchangeRate: data.exchangeRate
      } as any);
      res.status(201).json(portfolioAsset);
    } catch (error) {
      console.error("POST /api/portfolio/assets - Error:", error);
      if (error instanceof Error) {
        console.error("Error message:", error.message);
        console.error("Error stack:", error.stack);
      }
      res.status(400).json({ error: "Invalid portfolio asset data", details: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Transactions
  app.get("/api/transactions", async (req, res) => {
    try {
      const transactions = await storage.getTransactions(DEFAULT_USER_ID);
      const transactionsWithAssets = await Promise.all(
        transactions.map(async (transaction) => {
          const asset = await storage.getAssets().then(assets =>
            assets.find(a => a.id === transaction.assetId)
          );
          return { ...transaction, asset };
        })
      );
      res.json(transactionsWithAssets);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch transactions" });
    }
  });

  app.post("/api/transactions", async (req, res) => {
    try {
      const data = insertTransactionSchema.parse(req.body);
      const transaction = await storage.createTransaction({
        ...data,
        userId: DEFAULT_USER_ID
      });
      
      // Update portfolio asset
      const existingPortfolioAsset = await storage.getPortfolioAsset(DEFAULT_USER_ID, data.assetId);
      
      if (existingPortfolioAsset) {
        const newQuantity = data.type === "buy" 
          ? parseFloat(existingPortfolioAsset.quantity) + parseFloat(data.quantity)
          : parseFloat(existingPortfolioAsset.quantity) - parseFloat(data.quantity);
        
        if (data.type === "buy") {
          const currentInvested = parseFloat(existingPortfolioAsset.totalInvested);
          const newInvestment = parseFloat(data.totalAmount);
          const totalInvested = currentInvested + newInvestment;
          const totalQuantity = parseFloat(existingPortfolioAsset.quantity) + parseFloat(data.quantity);
          const newAveragePrice = totalInvested / totalQuantity;

          await storage.updatePortfolioAsset(existingPortfolioAsset.id, {
            quantity: newQuantity.toString(),
            averagePurchasePrice: newAveragePrice.toString(),
            totalInvested: totalInvested.toString()
          });
        } else {
          await storage.updatePortfolioAsset(existingPortfolioAsset.id, {
            quantity: newQuantity.toString()
          });
        }
      } else if (data.type === "buy") {
        await storage.createPortfolioAsset({
          userId: DEFAULT_USER_ID,
          assetId: data.assetId,
          quantity: data.quantity,
          averagePurchasePrice: data.price,
          totalInvested: data.totalAmount,
          purchaseDate: undefined,
          exchangeRate: undefined
        } as any);
      }
      
      res.status(201).json(transaction);
    } catch (error) {
      res.status(400).json({ error: "Invalid transaction data" });
    }
  });

  // Income Records
  app.get("/api/income", async (req, res) => {
    try {
      const incomeRecords = await storage.getIncomeRecords(DEFAULT_USER_ID);
      res.json(incomeRecords);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch income records" });
    }
  });

  app.post("/api/income", async (req, res) => {
    try {
      const data = insertIncomeRecordSchema.parse(req.body);
      const income = await storage.createIncomeRecord({
        ...data,
        userId: DEFAULT_USER_ID
      });
      res.status(201).json(income);
    } catch (error) {
      res.status(400).json({ error: "Invalid income data" });
    }
  });

  // Expense Records
  app.get("/api/expenses", async (req, res) => {
    try {
      const expenseRecords = await storage.getExpenseRecords(DEFAULT_USER_ID);
      res.json(expenseRecords);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch expense records" });
    }
  });

  app.post("/api/expenses", async (req, res) => {
    try {
      const data = insertExpenseRecordSchema.parse(req.body);
      const expense = await storage.createExpenseRecord({
        ...data,
        userId: DEFAULT_USER_ID
      });
      res.status(201).json(expense);
    } catch (error) {
      res.status(400).json({ error: "Invalid expense data" });
    }
  });

  // Currency conversion
  app.get("/api/currency/convert", async (req, res) => {
    try {
      const { amount, from, to } = req.query;
      
      if (!amount || !from || !to) {
        return res.status(400).json({ error: "Missing required parameters" });
      }

      const convertedAmount = await currencyConverter.convert(
        parseFloat(amount as string),
        from as string,
        to as string
      );

      res.json({
        amount: parseFloat(amount as string),
        from,
        to,
        convertedAmount,
        rate: currencyConverter.getExchangeRate(from as string, to as string)
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to convert currency" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
