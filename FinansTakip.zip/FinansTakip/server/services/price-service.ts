import type { IPriceProvider, PriceRequest, PriceQuote, ConvertedPriceQuote, ExchangeRate } from "@shared/types/price";
import { CoinGeckoProvider } from '../price-providers/coingecko-provider';
import { ExchangeRateProvider } from '../price-providers/exchangerate-provider';
import { FinnhubProvider } from '../price-providers/finnhub-provider';
import { YahooFinanceProvider } from '../price-providers/yahoo-finance-provider';

interface CacheEntry {
  data: PriceQuote;
  expiresAt: number;
}

interface CurrencyCache {
  [key: string]: {
    rate: number;
    expiresAt: number;
  };
}

export class PriceService {
  private providers: Map<string, IPriceProvider> = new Map();
  private cache: Map<string, CacheEntry> = new Map();
  private currencyCache: CurrencyCache = {};
  private maxCacheSize = 1000;
  
  // TTL in milliseconds
  private cacheTTL = {
    crypto: 30 * 1000,      // 30 seconds for crypto
    stock: 60 * 1000,       // 1 minute for stocks
    forex: 60 * 1000,       // 1 minute for forex intraday
    commodity: 5 * 60 * 1000, // 5 minutes for commodities
  };

  // Provider chains per asset class
  private providerChains = {
    crypto: ['CoinGecko'],
    forex: ['ExchangeRate'],
    stock: ['Finnhub', 'YahooFinance'], // Primary: Finnhub, Backup: Yahoo Finance
    etf: ['Finnhub', 'YahooFinance'],
    commodity: [], // Will add Alpha Vantage later
  };

  constructor() {
    this.initializeProviders();
  }

  private initializeProviders() {
    this.providers.set('CoinGecko', new CoinGeckoProvider());
    this.providers.set('ExchangeRate', new ExchangeRateProvider());
    this.providers.set('Finnhub', new FinnhubProvider());
    this.providers.set('YahooFinance', new YahooFinanceProvider());
  }

  async getQuote(request: PriceRequest): Promise<ConvertedPriceQuote> {
    const cacheKey = this.getCacheKey(request);
    
    // Check cache first
    const cached = this.cache.get(cacheKey);
    if (cached && cached.expiresAt > Date.now()) {
      return await this.addCurrencyConversions(cached.data);
    }

    // Get provider chain for asset type
    const chain = this.getProviderChain(request);
    
    let lastError: Error | null = null;
    
    for (const providerName of chain) {
      const provider = this.providers.get(providerName);
      if (!provider || !provider.supports(request)) {
        continue;
      }

      try {
        const quote = await provider.getQuote(request);
        
        // Cache the result
        this.setCache(cacheKey, quote, request.type || 'stock');
        
        return await this.addCurrencyConversions(quote);
      } catch (error) {
        console.warn(`Provider ${providerName} failed for ${request.symbol}:`, error);
        lastError = error as Error;
        continue;
      }
    }

    throw lastError || new Error(`No provider available for ${request.symbol}`);
  }

  async getMultipleQuotes(requests: PriceRequest[]): Promise<ConvertedPriceQuote[]> {
    const results: ConvertedPriceQuote[] = [];
    
    // Group requests by provider for batching
    const providerGroups: Map<string, PriceRequest[]> = new Map();
    
    for (const request of requests) {
      const chain = this.getProviderChain(request);
      
      // Find the first available provider in the chain
      let selectedProvider: string | null = null;
      for (const providerName of chain) {
        const provider = this.providers.get(providerName);
        if (provider && provider.supports(request)) {
          selectedProvider = providerName;
          break;
        }
      }
      
      if (selectedProvider) {
        if (!providerGroups.has(selectedProvider)) {
          providerGroups.set(selectedProvider, []);
        }
        providerGroups.get(selectedProvider)!.push(request);
      }
    }

    // Track processed symbols to avoid duplicates
    const processedSymbols = new Set<string>();
    
    // Process each provider group
    for (const [providerName, groupRequests] of Array.from(providerGroups.entries())) {
      const provider = this.providers.get(providerName);
      if (!provider) continue;

      const failedRequests: PriceRequest[] = [];

      try {
        if (provider.getMultipleQuotes) {
          // Use batch API if available
          const quotes = await provider.getMultipleQuotes(groupRequests);
          
          // Track successful quotes
          const successfulSymbols = new Set(quotes.map(q => q.symbol));
          
          for (const quote of quotes) {
            const request = groupRequests.find((r: PriceRequest) => r.symbol === quote.symbol);
            if (request) {
              this.setCache(this.getCacheKey(request), quote, request.type || 'stock');
              results.push(await this.addCurrencyConversions(quote));
              processedSymbols.add(request.symbol);
            }
          }
          
          // Identify failed requests for fallback
          for (const request of groupRequests) {
            if (!successfulSymbols.has(request.symbol) && !processedSymbols.has(request.symbol)) {
              failedRequests.push(request);
            }
          }
        } else {
          // Fallback to individual requests
          for (const request of groupRequests) {
            if (processedSymbols.has(request.symbol)) continue;
            
            try {
              const quote = await provider.getQuote(request);
              this.setCache(this.getCacheKey(request), quote, request.type || 'stock');
              results.push(await this.addCurrencyConversions(quote));
              processedSymbols.add(request.symbol);
            } catch (error) {
              console.warn(`Failed to get quote for ${request.symbol} from ${providerName}:`, error);
              failedRequests.push(request);
            }
          }
        }
      } catch (error) {
        console.error(`Batch request failed for provider ${providerName}:`, error);
        // All requests failed, add them for fallback
        failedRequests.push(...groupRequests.filter(r => !processedSymbols.has(r.symbol)));
      }
      
      // Try fallback providers for failed requests
      for (const failedRequest of failedRequests) {
        if (processedSymbols.has(failedRequest.symbol)) continue;
        
        try {
          const quote = await this.getQuote(failedRequest);
          results.push(quote);
          processedSymbols.add(failedRequest.symbol);
        } catch (error) {
          console.warn(`All providers failed for ${failedRequest.symbol}:`, error);
        }
      }
    }

    return results;
  }

  async getExchangeRate(from: string, to: string): Promise<ExchangeRate> {
    const cacheKey = `${from}_${to}`;
    const cached = this.currencyCache[cacheKey];
    
    if (cached && cached.expiresAt > Date.now()) {
      return {
        from,
        to,
        rate: cached.rate,
        source: 'Cache',
        observedAt: new Date(),
      };
    }

    // Currently only supports USD/TRY
    if (from === 'USD' && to === 'TRY') {
      const provider = this.providers.get('ExchangeRate');
      if (provider) {
        try {
          const quote = await provider.getQuote({ symbol: 'USDTRY', type: 'forex' });
          
          // Cache for 1 minute
          this.currencyCache[cacheKey] = {
            rate: quote.price,
            expiresAt: Date.now() + 60 * 1000,
          };

          return {
            from,
            to,
            rate: quote.price,
            source: quote.source,
            observedAt: quote.observedAt,
          };
        } catch (error) {
          console.error('Exchange rate fetch failed:', error);
        }
      }
    }

    // No hardcoded fallback - throw error if no provider available
    throw new Error(`Exchange rate ${from}/${to} not available - all providers failed`);
  }

  private async addCurrencyConversions(quote: PriceQuote): Promise<ConvertedPriceQuote> {
    const converted: ConvertedPriceQuote = { ...quote };
    
    try {
      if (quote.currency === 'USD') {
        // Convert USD to TRY
        const exchangeRate = await this.getExchangeRate('USD', 'TRY');
        converted.priceTRY = quote.price * exchangeRate.rate;
        converted.priceUSD = quote.price;
      } else if (quote.currency === 'TRY') {
        // Convert TRY to USD
        const exchangeRate = await this.getExchangeRate('USD', 'TRY');
        converted.priceUSD = quote.price / exchangeRate.rate;
        converted.priceTRY = quote.price;
      }
    } catch (error) {
      console.warn('Currency conversion failed:', error);
    }

    return converted;
  }

  private getProviderChain(request: PriceRequest): string[] {
    const type = request.type || 'stock';
    return this.providerChains[type as keyof typeof this.providerChains] || [];
  }

  private getCacheKey(request: PriceRequest): string {
    return `${request.type || 'stock'}_${request.symbol}_${request.market || 'default'}_${request.quoteCurrency || 'default'}`;
  }

  private setCache(key: string, quote: PriceQuote, type: string) {
    // Implement LRU-like behavior
    if (this.cache.size >= this.maxCacheSize) {
      const oldestKey = this.cache.keys().next().value;
      if (oldestKey) {
        this.cache.delete(oldestKey);
      }
    }

    const ttl = this.cacheTTL[type as keyof typeof this.cacheTTL] || this.cacheTTL.stock;
    
    this.cache.set(key, {
      data: quote,
      expiresAt: Date.now() + ttl,
    });
  }

  // Clean expired cache entries
  private cleanupCache() {
    const now = Date.now();
    for (const [key, entry] of Array.from(this.cache.entries())) {
      if (entry.expiresAt <= now) {
        this.cache.delete(key);
      }
    }
    
    // Clean currency cache
    for (const [key, entry] of Object.entries(this.currencyCache)) {
      if (entry.expiresAt <= now) {
        delete this.currencyCache[key];
      }
    }
  }

  // Initialize cleanup interval
  startCleanupInterval() {
    setInterval(() => {
      this.cleanupCache();
    }, 5 * 60 * 1000); // Every 5 minutes
  }
}

// Export singleton instance
export const priceService = new PriceService();
priceService.startCleanupInterval();