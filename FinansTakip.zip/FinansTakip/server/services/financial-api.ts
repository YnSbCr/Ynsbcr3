interface PriceData {
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
  currency: string;
}

interface SearchResult {
  symbol: string;
  name: string;
  type: string;
  exchange?: string;
}

export class FinancialAPIService {
  private alphaVantageKey: string;
  private cryptoApiKey: string;

  constructor() {
    this.alphaVantageKey = process.env.ALPHA_VANTAGE_API_KEY || process.env.VITE_ALPHA_VANTAGE_API_KEY || "";
    this.cryptoApiKey = process.env.CRYPTO_API_KEY || process.env.VITE_CRYPTO_API_KEY || "";
  }

  async getStockPrice(symbol: string): Promise<PriceData | null> {
    try {
      if (!this.alphaVantageKey) {
        // Return mock data if no API key
        return this.getMockStockPrice(symbol);
      }

      const response = await fetch(
        `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${symbol}&apikey=${this.alphaVantageKey}`
      );

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      const quote = data["Global Quote"];

      if (!quote || Object.keys(quote).length === 0) {
        return null;
      }

      const price = parseFloat(quote["05. price"]);
      const change = parseFloat(quote["09. change"]);
      const changePercent = parseFloat(quote["10. change percent"].replace("%", ""));

      return {
        symbol,
        price,
        change,
        changePercent,
        currency: "USD"
      };
    } catch (error) {
      console.error(`Error fetching stock price for ${symbol}:`, error);
      return null;
    }
  }

  async getCryptoPrice(symbol: string): Promise<PriceData | null> {
    try {
      const response = await fetch(
        `https://api.coingecko.com/api/v3/simple/price?ids=${symbol}&vs_currencies=usd&include_24hr_change=true`
      );

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      const coinData = data[symbol];

      if (!coinData) {
        return null;
      }

      return {
        symbol: symbol.toUpperCase(),
        price: coinData.usd,
        change: 0, // CoinGecko doesn't provide absolute change
        changePercent: coinData.usd_24h_change || 0,
        currency: "USD"
      };
    } catch (error) {
      console.error(`Error fetching crypto price for ${symbol}:`, error);
      return null;
    }
  }

  async getGoldPrice(): Promise<PriceData | null> {
    try {
      // Using a free gold API or fallback to mock data
      const response = await fetch("https://api.metals.live/v1/spot/gold");
      
      if (!response.ok) {
        return this.getMockGoldPrice();
      }

      const data = await response.json();
      const pricePerOz = data.price;
      const pricePerGram = pricePerOz / 31.1035; // Convert oz to gram
      const priceInTRY = pricePerGram * 30; // Approximate USD to TRY conversion

      return {
        symbol: "GOLD_TR",
        price: priceInTRY,
        change: 0,
        changePercent: 1.85,
        currency: "TRY"
      };
    } catch (error) {
      console.error("Error fetching gold price:", error);
      return this.getMockGoldPrice();
    }
  }

  async searchAssets(query: string): Promise<SearchResult[]> {
    try {
      if (!this.alphaVantageKey) {
        return this.getMockSearchResults(query);
      }

      const response = await fetch(
        `https://www.alphavantage.co/query?function=SYMBOL_SEARCH&keywords=${query}&apikey=${this.alphaVantageKey}`
      );

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      const matches = data.bestMatches || [];

      return matches.slice(0, 10).map((match: any) => ({
        symbol: match["1. symbol"],
        name: match["2. name"],
        type: match["3. type"],
        exchange: match["4. region"]
      }));
    } catch (error) {
      console.error("Error searching assets:", error);
      return this.getMockSearchResults(query);
    }
  }

  private getMockStockPrice(symbol: string): PriceData {
    const mockPrices: Record<string, PriceData> = {
      "AAPL": { symbol: "AAPL", price: 175.84, change: 3.67, changePercent: 2.13, currency: "USD" },
      "TSLA": { symbol: "TSLA", price: 242.65, change: -2.85, changePercent: -1.16, currency: "USD" },
      "MSFT": { symbol: "MSFT", price: 378.85, change: 8.45, changePercent: 2.28, currency: "USD" },
      "GOOGL": { symbol: "GOOGL", price: 142.56, change: 2.34, changePercent: 1.67, currency: "USD" }
    };

    return mockPrices[symbol] || { symbol, price: 100, change: 0, changePercent: 0, currency: "USD" };
  }

  private getMockGoldPrice(): PriceData {
    return {
      symbol: "GOLD_TR",
      price: 1950.00,
      change: 35.50,
      changePercent: 1.85,
      currency: "TRY"
    };
  }

  private getMockSearchResults(query: string): SearchResult[] {
    const mockResults: SearchResult[] = [
      { symbol: "AAPL", name: "Apple Inc.", type: "Equity", exchange: "NASDAQ" },
      { symbol: "TSLA", name: "Tesla Inc.", type: "Equity", exchange: "NASDAQ" },
      { symbol: "MSFT", name: "Microsoft Corporation", type: "Equity", exchange: "NASDAQ" },
      { symbol: "GOOGL", name: "Alphabet Inc.", type: "Equity", exchange: "NASDAQ" },
      { symbol: "AMZN", name: "Amazon.com Inc.", type: "Equity", exchange: "NASDAQ" }
    ];

    return mockResults.filter(result => 
      result.symbol.toLowerCase().includes(query.toLowerCase()) ||
      result.name.toLowerCase().includes(query.toLowerCase())
    );
  }
}

export const financialAPI = new FinancialAPIService();
