interface ExchangeRates {
  [currency: string]: number;
}

export class CurrencyConverter {
  private exchangeRates: ExchangeRates = {};
  private lastUpdated: Date | null = null;
  private updateInterval = 3600000; // 1 hour in milliseconds

  constructor() {
    this.updateRates();
  }

  private async updateRates(): Promise<void> {
    try {
      const apiKey = process.env.EXCHANGE_RATE_API_KEY || process.env.VITE_EXCHANGE_RATE_API_KEY;
      
      if (!apiKey) {
        // Use mock rates if no API key
        this.exchangeRates = {
          USD: 1,
          TRY: 30.0,
          EUR: 0.85,
          GBP: 0.73
        };
        this.lastUpdated = new Date();
        return;
      }

      const response = await fetch(`https://api.exchangerate-api.com/v4/latest/USD?access_key=${apiKey}`);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      this.exchangeRates = data.rates;
      this.lastUpdated = new Date();
    } catch (error) {
      console.error("Error updating exchange rates:", error);
      // Fallback to mock rates
      this.exchangeRates = {
        USD: 1,
        TRY: 30.0,
        EUR: 0.85,
        GBP: 0.73
      };
      this.lastUpdated = new Date();
    }
  }

  async convert(amount: number, fromCurrency: string, toCurrency: string): Promise<number> {
    // Check if rates need updating
    if (!this.lastUpdated || Date.now() - this.lastUpdated.getTime() > this.updateInterval) {
      await this.updateRates();
    }

    if (fromCurrency === toCurrency) {
      return amount;
    }

    const fromRate = this.exchangeRates[fromCurrency] || 1;
    const toRate = this.exchangeRates[toCurrency] || 1;

    // Convert to USD first, then to target currency
    const usdAmount = amount / fromRate;
    return usdAmount * toRate;
  }

  getExchangeRate(fromCurrency: string, toCurrency: string): number {
    if (fromCurrency === toCurrency) {
      return 1;
    }

    const fromRate = this.exchangeRates[fromCurrency] || 1;
    const toRate = this.exchangeRates[toCurrency] || 1;

    return toRate / fromRate;
  }

  getLastUpdated(): Date | null {
    return this.lastUpdated;
  }
}

export const currencyConverter = new CurrencyConverter();
