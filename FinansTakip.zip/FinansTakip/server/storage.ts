import { 
  type User, 
  type InsertUser,
  type AssetCategory,
  type InsertAssetCategory,
  type Asset,
  type InsertAsset,
  type PortfolioAsset,
  type InsertPortfolioAsset,
  type Transaction,
  type InsertTransaction,
  type IncomeRecord,
  type InsertIncomeRecord,
  type ExpenseRecord,
  type InsertExpenseRecord,
  // Multi-platform trading types
  type Platform,
  type InsertPlatform,
  type PlatformAccount,
  type InsertPlatformAccount,
  type Currency,
  type InsertCurrency,
  type Market,
  type InsertMarket,
  type Trade,
  type InsertTrade,
  type FxRate,
  type InsertFxRate,
  type PriceTick,
  type InsertPriceTick,
  users,
  assetCategories,
  assets,
  portfolioAssets,
  transactions,
  incomeRecords,
  expenseRecords,
  platforms,
  platformAccounts,
  currencies,
  markets,
  trades,
  fxRates,
  priceTicks
} from "@shared/schema";
import { supabase } from "./db";
// Keep db import for future reference but use supabase HTTP API
// import { db } from "./db";
// import { eq, and, sql } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Asset Categories
  getAssetCategories(): Promise<AssetCategory[]>;
  createAssetCategory(category: InsertAssetCategory): Promise<AssetCategory>;
  
  // Assets
  getAssets(): Promise<Asset[]>;
  getAssetsByCategory(categoryId: string): Promise<Asset[]>;
  getAssetBySymbol(symbol: string): Promise<Asset | undefined>;
  createAsset(asset: InsertAsset): Promise<Asset>;
  updateAssetPrice(assetId: string, price: string, currency: string): Promise<Asset | undefined>;
  
  // Portfolio Assets
  getPortfolioAssets(userId: string): Promise<PortfolioAsset[]>;
  getPortfolioAsset(userId: string, assetId: string): Promise<PortfolioAsset | undefined>;
  createPortfolioAsset(portfolioAsset: any): Promise<PortfolioAsset>;
  updatePortfolioAsset(id: string, updates: Partial<PortfolioAsset>): Promise<PortfolioAsset | undefined>;
  deletePortfolioAsset(id: string): Promise<boolean>;
  
  // Transactions
  getTransactions(userId: string): Promise<Transaction[]>;
  getTransactionsByAsset(userId: string, assetId: string): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  
  // Income Records
  getIncomeRecords(userId: string): Promise<IncomeRecord[]>;
  createIncomeRecord(income: InsertIncomeRecord): Promise<IncomeRecord>;
  
  // Expense Records
  getExpenseRecords(userId: string): Promise<ExpenseRecord[]>;
  createExpenseRecord(expense: InsertExpenseRecord): Promise<ExpenseRecord>;

  // Multi-platform trading
  // Platforms
  getPlatforms(): Promise<Platform[]>;
  createPlatform(platform: InsertPlatform): Promise<Platform>;
  
  // Currencies
  getCurrencies(): Promise<Currency[]>;
  createCurrency(currency: InsertCurrency): Promise<Currency>;
  
  // Markets
  getMarkets(platformId?: string): Promise<Market[]>;
  createMarket(market: InsertMarket): Promise<Market>;
  
  // Platform Accounts
  getPlatformAccounts(userId: string): Promise<PlatformAccount[]>;
  createPlatformAccount(account: InsertPlatformAccount): Promise<PlatformAccount>;
  
  // Trades
  getTrades(userId: string): Promise<Trade[]>;
  createTrade(trade: InsertTrade): Promise<Trade>;
  
  // FX Rates
  getLatestFxRate(baseCurrency: string, quoteCurrency: string): Promise<FxRate | undefined>;
  createFxRate(fxRate: InsertFxRate): Promise<FxRate>;
  
  // Price Ticks
  getLatestPrice(assetId: string, quoteCurrency: string): Promise<PriceTick | undefined>;
  createPriceTick(priceTick: InsertPriceTick): Promise<PriceTick>;
}

export class DatabaseStorage implements IStorage {
  constructor() {
    this.initializeDefaultData();
  }

  private async initializeDefaultData() {
    try {
      // Check if default user exists
      const existingUser = await this.getUserByUsername("mehmet_yilmaz");
      if (!existingUser) {
        // Create default user
        await this.createUser({
          username: "mehmet_yilmaz",
          email: "mehmet@example.com",
          name: "Mehmet Yılmaz",
          preferred_currency: "TRY"
        });
      }

      // Check if asset categories exist
      const existingCategories = await this.getAssetCategories();
      if (existingCategories.length === 0) {
        // Create asset categories
        const categoryData = [
          { name: "Abd Borsası", type: "stocks", market: "US", icon: "fas fa-chart-line" },
          { name: "BIST", type: "stocks", market: "BIST", icon: "fas fa-building" },
          { name: "Kripto Para", type: "crypto", market: "global", icon: "fab fa-bitcoin" },
          { name: "Altın & Gümüş", type: "commodities", market: "global", icon: "fas fa-coins" },
          { name: "ETF", type: "etf", market: "global", icon: "fas fa-layer-group" },
          { name: "Fonlar", type: "funds", market: "global", icon: "fas fa-piggy-bank" }
        ];

        for (const category of categoryData) {
          await this.createAssetCategory(category);
        }

        // Create sample assets
        const categories = await this.getAssetCategories();
        const usStocksCategory = categories.find(c => c.type === "stocks" && c.market === "US");
        const cryptoCategory = categories.find(c => c.type === "crypto");
        const goldCategory = categories.find(c => c.type === "commodities");

        if (usStocksCategory) {
          await this.createAsset({
            symbol: "AAPL",
            name: "Apple Inc.",
            categoryId: usStocksCategory.id,
            currentPrice: "175.84",
            currency: "USD",
            metadata: { marketCap: "2.8T", volume: "45M" }
          });

          await this.createAsset({
            symbol: "TSLA",
            name: "Tesla Inc.",
            categoryId: usStocksCategory.id,
            currentPrice: "242.65",
            currency: "USD",
            metadata: { marketCap: "775B", volume: "28M" }
          });
        }

        if (cryptoCategory) {
          await this.createAsset({
            symbol: "BTC",
            name: "Bitcoin",
            categoryId: cryptoCategory.id,
            currentPrice: "43250.00",
            currency: "USD",
            metadata: { marketCap: "845B", volume: "25B" }
          });

          await this.createAsset({
            symbol: "ETH",
            name: "Ethereum",
            categoryId: cryptoCategory.id,
            currentPrice: "2650.00",
            currency: "USD",
            metadata: { marketCap: "318B", volume: "12B" }
          });
        }

        if (goldCategory) {
          await this.createAsset({
            symbol: "GOLD_TR",
            name: "Gram Altın",
            categoryId: goldCategory.id,
            currentPrice: "1950.00",
            currency: "TRY",
            metadata: { unit: "gram", purity: "24k" }
          });

          await this.createAsset({
            symbol: "SILVER",
            name: "Gümüş",
            categoryId: goldCategory.id,
            currentPrice: "14.65",
            currency: "TRY",
            metadata: { unit: "gram", purity: "999" }
          });
        }
      }

      // Initialize multi-platform trading data
      const existingPlatforms = await this.getPlatforms();
      if (existingPlatforms.length === 0) {
        // Create platforms
        const binance = await this.createPlatform({
          name: "Binance",
          type: "cex",
          metadata: { website: "https://binance.com", fees: "0.1%" }
        });

        const midas = await this.createPlatform({
          name: "Midas",
          type: "cex", 
          metadata: { website: "https://midas.investments", fees: "0.1%" }
        });

        // Create currencies
        const existingCurrencies = await this.getCurrencies();
        if (existingCurrencies.length === 0) {
          await this.createCurrency({
            code: "TRY",
            type: "fiat",
            decimals: 2,
            metadata: { name: "Turkish Lira", symbol: "₺" }
          });

          await this.createCurrency({
            code: "USD",
            type: "fiat", 
            decimals: 2,
            metadata: { name: "US Dollar", symbol: "$" }
          });

          await this.createCurrency({
            code: "USDT",
            type: "crypto",
            decimals: 6,
            metadata: { name: "Tether USD", symbol: "USDT" }
          });

          await this.createCurrency({
            code: "SOL",
            type: "crypto",
            decimals: 8,
            metadata: { name: "Solana", symbol: "SOL" }
          });
        }

        // Create SOL asset if not exists
        const existingAssets = await this.getAssets();
        const solAsset = existingAssets.find(a => a.symbol === "SOL");
        let solAssetId = solAsset?.id;

        if (!solAsset) {
          const existingCategories = await this.getAssetCategories();
          const cryptoCategory = existingCategories.find((c: AssetCategory) => c.type === "crypto");
          if (cryptoCategory) {
            const newSolAsset = await this.createAsset({
              symbol: "SOL",
              name: "Solana",
              categoryId: cryptoCategory.id,
              currentPrice: "250.00",
              currency: "USD",
              metadata: { blockchain: "Solana", type: "Layer 1" }
            });
            solAssetId = newSolAsset.id;
          }
        }

        // Create markets
        if (solAssetId) {
          await this.createMarket({
            platformId: binance.id,
            baseAssetId: solAssetId,
            quoteCurrency: "USDT",
            platformSymbol: "SOLUSDT",
            minQuantity: "0.01",
            stepSize: "0.01",
            tickSize: "0.01"
          });

          await this.createMarket({
            platformId: midas.id,
            baseAssetId: solAssetId,
            quoteCurrency: "TRY",
            platformSymbol: "SOL/TRY",
            minQuantity: "0.01", 
            stepSize: "0.01",
            tickSize: "0.01"
          });
        }

        // Add some initial FX rates
        const now = new Date();
        await this.createFxRate({
          baseCurrency: "USD",
          quoteCurrency: "TRY",
          rate: "32.50",
          source: "manual",
          observedAt: now
        });

        await this.createFxRate({
          baseCurrency: "USDT",
          quoteCurrency: "USD",
          rate: "1.00",
          source: "manual", 
          observedAt: now
        });
      }
    } catch (error) {
      console.error("Error initializing default data:", error);
    }
  }

  async getUser(id: string): Promise<User | undefined> {
    const { data: user, error } = await supabase
      .from('users')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error && error.code !== 'PGRST116') { // PGRST116 = not found
      console.error('Error getting user:', error);
      return undefined;
    }
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const { data: user, error } = await supabase
      .from('users')
      .select('*')
      .eq('username', username)
      .single();
    
    if (error && error.code !== 'PGRST116') {
      console.error('Error getting user by username:', error);
      return undefined;
    }
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const { data: user, error } = await supabase
      .from('users')
      .insert(insertUser)
      .select()
      .single();
    
    if (error) {
      console.error('Error creating user:', error);
      throw error;
    }
    return user;
  }

  async getAssetCategories(): Promise<AssetCategory[]> {
    const { data: categories, error } = await supabase
      .from('asset_categories')
      .select('*');
    
    if (error) {
      console.error('Error getting asset categories:', error);
      throw error;
    }
    return categories || [];
  }

  async createAssetCategory(insertCategory: InsertAssetCategory): Promise<AssetCategory> {
    const { data: category, error } = await supabase
      .from('asset_categories')
      .insert(insertCategory)
      .select()
      .single();
    
    if (error) {
      console.error('Error creating asset category:', error);
      throw error;
    }
    return category;
  }

  async getAssets(): Promise<Asset[]> {
    const { data: assets, error } = await supabase
      .from('assets')
      .select('*');
    
    if (error) {
      console.error('Error getting assets:', error);
      throw error;
    }
    return assets || [];
  }

  async getAssetsByCategory(categoryId: string): Promise<Asset[]> {
    const { data: assets, error } = await supabase
      .from('assets')
      .select('*')
      .eq('categoryId', categoryId);
    
    if (error) {
      console.error('Error getting assets by category:', error);
      throw error;
    }
    return assets || [];
  }

  async getAssetBySymbol(symbol: string): Promise<Asset | undefined> {
    const { data: asset, error } = await supabase
      .from('assets')
      .select('*')
      .eq('symbol', symbol)
      .single();
    
    if (error && error.code !== 'PGRST116') {
      console.error('Error getting asset by symbol:', error);
      return undefined;
    }
    return asset || undefined;
  }

  async createAsset(insertAsset: InsertAsset): Promise<Asset> {
    const { data: asset, error } = await supabase
      .from('assets')
      .insert(insertAsset)
      .select()
      .single();
    
    if (error) {
      console.error('Error creating asset:', error);
      throw error;
    }
    return asset;
  }

  async updateAssetPrice(assetId: string, price: string, currency: string): Promise<Asset | undefined> {
    const [asset] = await db
      .update(assets)
      .set({ 
        currentPrice: price, 
        currency, 
        lastUpdated: new Date() 
      })
      .where(eq(assets.id, assetId))
      .returning();
    return asset || undefined;
  }

  async getPortfolioAssets(userId: string): Promise<PortfolioAsset[]> {
    const { data: assets, error } = await supabase
      .from('portfolio_assets')
      .select('*')
      .eq('user_id', userId);
    
    if (error) {
      console.error('Error getting portfolio assets:', error);
      throw error;
    }
    return assets || [];
  }

  async getPortfolioAsset(userId: string, assetId: string): Promise<PortfolioAsset | undefined> {
    const [portfolioAsset] = await db
      .select()
      .from(portfolioAssets)
      .where(and(
        eq(portfolioAssets.userId, userId),
        eq(portfolioAssets.assetId, assetId)
      ));
    return portfolioAsset || undefined;
  }

  async createPortfolioAsset(insertPortfolioAsset: any): Promise<PortfolioAsset> {
    // Ensure default user exists
    const userId = insertPortfolioAsset.userId || 'default-user';
    await this.ensureDefaultUser(userId);
    
    // Ensure asset exists
    await this.ensureAssetExists(insertPortfolioAsset.assetId);
    
    // Map camelCase to snake_case for database
    const dbData = {
      user_id: userId,
      asset_id: insertPortfolioAsset.assetId,
      quantity: insertPortfolioAsset.quantity,
      average_purchase_price: insertPortfolioAsset.averagePurchasePrice,
      purchase_currency: insertPortfolioAsset.purchaseCurrency,
      total_invested: insertPortfolioAsset.totalInvested,
      purchase_date: insertPortfolioAsset.purchaseDate,
      exchange_rate: insertPortfolioAsset.exchangeRate
    };
    
    const { data: portfolioAsset, error } = await supabase
      .from('portfolio_assets')
      .insert(dbData)
      .select()
      .single();
    
    if (error) {
      console.error('Error creating portfolio asset:', error);
      throw error;
    }
    return portfolioAsset;
  }
  
  private async ensureAssetExists(assetId: string): Promise<void> {
    // Check if asset exists, create if not
    const { data: existingAsset } = await supabase
      .from('assets')
      .select('id')
      .eq('id', assetId)
      .single();
    
    if (!existingAsset) {
      console.log(`Creating asset: ${assetId}`);
      
      // Determine asset type and details based on symbol
      let assetType = 'stock';
      let name = assetId;
      
      if (assetId.match(/^(BTC|ETH|ADA|XRP|DOT|AVAX|MATIC|SOL|DOGE|LTC|BNB|UNI|LINK)$/i)) {
        assetType = 'crypto';
        name = `${assetId} Cryptocurrency`;
      } else if (assetId.endsWith('.IS')) {
        assetType = 'stock';
        name = `${assetId.replace('.IS', '')} (BIST)`;
      } else {
        name = `${assetId} Stock`;
      }
      
      const { error } = await supabase
        .from('assets')
        .insert({
          id: assetId,
          name: name,
          symbol: assetId,
          // Removed 'type' field as it doesn't exist in database schema
          category_id: null // Will set later if needed
        });
      
      if (error) {
        console.error('Error creating asset:', error);
        // Don't throw, continue with existing asset
      }
    }
  }
  
  private async ensureDefaultUser(userId: string): Promise<void> {
    // Check if user exists, create if not
    const { data: existingUser } = await supabase
      .from('users')
      .select('id')
      .eq('id', userId)
      .single();
    
    if (!existingUser) {
      console.log(`Creating default user: ${userId}`);
      const { error } = await supabase
        .from('users')
        .insert({
          id: userId,
          email: 'default@example.com',
          username: 'default-user',
          name: 'Default User'
        });
      
      if (error) {
        console.error('Error creating default user:', error);
        // Don't throw, continue with existing user
      }
    }
  }

  async updatePortfolioAsset(id: string, updates: Partial<PortfolioAsset>): Promise<PortfolioAsset | undefined> {
    const [portfolioAsset] = await db
      .update(portfolioAssets)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(portfolioAssets.id, id))
      .returning();
    return portfolioAsset || undefined;
  }

  async deletePortfolioAsset(id: string): Promise<boolean> {
    const result = await db.delete(portfolioAssets).where(eq(portfolioAssets.id, id));
    return result.count > 0;
  }

  async getTransactions(userId: string): Promise<Transaction[]> {
    return await db.select().from(transactions).where(eq(transactions.userId, userId));
  }

  async getTransactionsByAsset(userId: string, assetId: string): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .where(and(
        eq(transactions.userId, userId),
        eq(transactions.assetId, assetId)
      ));
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const [transaction] = await db
      .insert(transactions)
      .values(insertTransaction)
      .returning();
    return transaction;
  }

  async getIncomeRecords(userId: string): Promise<IncomeRecord[]> {
    const { data: records, error } = await supabase
      .from('income_records')
      .select('*')
      .eq('user_id', userId);
    
    if (error) {
      console.error('Error getting income records:', error);
      throw error;
    }
    return records || [];
  }

  async createIncomeRecord(insertIncome: InsertIncomeRecord): Promise<IncomeRecord> {
    const [income] = await db
      .insert(incomeRecords)
      .values(insertIncome)
      .returning();
    return income;
  }

  async getExpenseRecords(userId: string): Promise<ExpenseRecord[]> {
    const { data: records, error } = await supabase
      .from('expense_records')
      .select('*')
      .eq('user_id', userId);
    
    if (error) {
      console.error('Error getting expense records:', error);
      throw error;
    }
    return records || [];
  }

  async createExpenseRecord(insertExpense: InsertExpenseRecord): Promise<ExpenseRecord> {
    const [expense] = await db
      .insert(expenseRecords)
      .values(insertExpense)
      .returning();
    return expense;
  }

  // Multi-platform trading implementations
  async getPlatforms(): Promise<Platform[]> {
    const { data: platforms, error } = await supabase
      .from('platforms')
      .select('*');
    
    if (error) {
      console.error('Error getting platforms:', error);
      throw error;
    }
    return platforms || [];
  }

  async createPlatform(platform: InsertPlatform): Promise<Platform> {
    const { data: createdPlatform, error } = await supabase
      .from('platforms')
      .insert(platform)
      .select()
      .single();
    
    if (error) {
      console.error('Error creating platform:', error);
      throw error;
    }
    return createdPlatform;
  }

  async getCurrencies(): Promise<Currency[]> {
    const { data: currencies, error } = await supabase
      .from('currencies')
      .select('*');
    
    if (error) {
      console.error('Error getting currencies:', error);
      throw error;
    }
    return currencies || [];
  }

  async createCurrency(currency: InsertCurrency): Promise<Currency> {
    const { data: createdCurrency, error } = await supabase
      .from('currencies')
      .insert(currency)
      .select()
      .single();
    
    if (error) {
      console.error('Error creating currency:', error);
      throw error;
    }
    return createdCurrency;
  }

  async getMarkets(platformId?: string): Promise<Market[]> {
    if (platformId) {
      return await db.select().from(markets).where(eq(markets.platformId, platformId));
    }
    return await db.select().from(markets);
  }

  async createMarket(market: InsertMarket): Promise<Market> {
    const [createdMarket] = await db.insert(markets).values(market).returning();
    return createdMarket;
  }

  async getPlatformAccounts(userId: string): Promise<PlatformAccount[]> {
    return await db.select().from(platformAccounts).where(eq(platformAccounts.userId, userId));
  }

  async createPlatformAccount(account: InsertPlatformAccount): Promise<PlatformAccount> {
    const [createdAccount] = await db.insert(platformAccounts).values(account).returning();
    return createdAccount;
  }

  async getTrades(userId: string): Promise<Trade[]> {
    return await db.select().from(trades).where(eq(trades.userId, userId));
  }

  async createTrade(trade: InsertTrade): Promise<Trade> {
    const [createdTrade] = await db.insert(trades).values(trade as any).returning();
    return createdTrade;
  }

  async getLatestFxRate(baseCurrency: string, quoteCurrency: string): Promise<FxRate | undefined> {
    const [fxRate] = await db
      .select()
      .from(fxRates)
      .where(and(
        eq(fxRates.baseCurrency, baseCurrency),
        eq(fxRates.quoteCurrency, quoteCurrency)
      ))
      .orderBy(sql`${fxRates.observedAt} DESC`)
      .limit(1);
    return fxRate || undefined;
  }

  async createFxRate(fxRate: InsertFxRate): Promise<FxRate> {
    const [createdFxRate] = await db.insert(fxRates).values(fxRate as any).returning();
    return createdFxRate;
  }

  async getLatestPrice(assetId: string, quoteCurrency: string): Promise<PriceTick | undefined> {
    const [priceTick] = await db
      .select()
      .from(priceTicks)
      .where(and(
        eq(priceTicks.assetId, assetId),
        eq(priceTicks.quoteCurrency, quoteCurrency)
      ))
      .orderBy(sql`${priceTicks.observedAt} DESC`)
      .limit(1);
    return priceTick || undefined;
  }

  async createPriceTick(priceTick: InsertPriceTick): Promise<PriceTick> {
    const [createdPriceTick] = await db.insert(priceTicks).values(priceTick as any).returning();
    return createdPriceTick;
  }
}

export const storage = new DatabaseStorage();
