import { createClient } from '@supabase/supabase-js';
import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import * as schema from "@shared/schema";

if (!process.env.SUPABASE_URL || !process.env.SUPABASE_ANON_KEY) {
  throw new Error(
    "SUPABASE_URL and SUPABASE_ANON_KEY must be set.",
  );
}

console.log('🔑 SUPABASE_SERVICE_ROLE_KEY exists:', !!process.env.SUPABASE_SERVICE_ROLE_KEY);

// Create Supabase client with service role key for server-side operations
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!serviceRoleKey) {
  console.warn('⚠️  SUPABASE_SERVICE_ROLE_KEY not found, falling back to SUPABASE_ANON_KEY');
}

export const supabase = createClient(
  process.env.SUPABASE_URL,
  serviceRoleKey || process.env.SUPABASE_ANON_KEY
);

// Construct Supabase connection string with secure password (try direct connection)
if (!process.env.SUPABASE_DB_PASSWORD) {
  throw new Error("SUPABASE_DB_PASSWORD must be set for database connection");
}

// Use the correct Supabase Transaction Pooler connection string provided by user
const databaseUrl = `postgresql://postgres.afvncfokkeicvtjpmjqt:${process.env.SUPABASE_DB_PASSWORD}@aws-1-eu-north-1.pooler.supabase.com:6543/postgres`;

console.log('🔍 Using Supabase direct connection with secure credentials');

const client = postgres(databaseUrl, {
  ssl: 'require',
  max: 10,
  idle_timeout: 20,
  connect_timeout: 10,
});

export const db = drizzle(client, { schema });
