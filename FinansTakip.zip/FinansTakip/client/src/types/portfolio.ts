export interface PortfolioSummary {
  totalValue: number;
  totalInvested: number;
  totalProfitLoss: number;
  totalProfitLossPercent: number;
  currency: string;
}

export interface AssetPrice {
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
  currency: string;
}

export interface PortfolioAssetWithDetails {
  id: string;
  userId: string;
  assetId: string;
  quantity: string;
  averagePurchasePrice: string;
  totalInvested: string;
  currentValue: number;
  profitLoss: number;
  profitLossPercent: number;
  asset: {
    id: string;
    symbol: string;
    name: string;
    categoryId: string;
    currentPrice: string;
    currency: string;
  };
  category: {
    id: string;
    name: string;
    type: string;
    market: string;
    icon: string;
  };
}

export interface AssetSearchResult {
  symbol: string;
  name: string;
  type: string;
  exchange?: string;
}

export interface IncomeExpenseSummary {
  totalIncome: number;
  totalExpenses: number;
  netIncome: number;
  currency: string;
}
