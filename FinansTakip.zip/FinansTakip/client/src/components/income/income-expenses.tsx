import { Card, CardContent } from "@/components/ui/card";
import { useIncomeExpenseSummary, useIncomeRecords, useExpenseRecords } from "@/hooks/use-financial-data";
import { Skeleton } from "@/components/ui/skeleton";

export function IncomeExpenses() {
  const summary = useIncomeExpenseSummary();
  const { data: incomeRecords, isLoading: incomeLoading } = useIncomeRecords();
  const { data: expenseRecords, isLoading: expensesLoading } = useExpenseRecords();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('tr-TR', {
      style: 'currency',
      currency: 'TRY',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  // Mock data for demo since we don't have sample data
  const mockIncomeData = [
    { type: "salary", label: "Maaş", amount: 18000, icon: "fas fa-money-bill-wave", color: "blue" },
    { type: "dividend", label: "Temettü", amount: 6500, icon: "fas fa-percentage", color: "purple" }
  ];

  const mockExpenseData = [
    { type: "kmh_loan", label: "KMH Kredisi", amount: 8450, icon: "fas fa-home", color: "red" },
    { type: "credit_card", label: "Kredi Kartı", amount: 10300, icon: "fas fa-credit-card", color: "orange" }
  ];

  if (incomeLoading || expensesLoading) {
    return (
      <Card className="mb-3">
        <CardContent className="p-4">
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div className="text-center p-3 bg-green-50 rounded-lg">
              <Skeleton className="h-6 w-6 mx-auto mb-2" />
              <Skeleton className="h-4 w-16 mx-auto mb-1" />
              <Skeleton className="h-5 w-20 mx-auto" />
            </div>
            <div className="text-center p-3 bg-red-50 rounded-lg">
              <Skeleton className="h-6 w-6 mx-auto mb-2" />
              <Skeleton className="h-4 w-16 mx-auto mb-1" />
              <Skeleton className="h-5 w-20 mx-auto" />
            </div>
          </div>
          <div className="space-y-3">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="flex items-center justify-between py-2 border-b border-border">
                <div className="flex items-center space-x-3">
                  <Skeleton className="w-6 h-6 rounded" />
                  <Skeleton className="h-4 w-16" />
                </div>
                <Skeleton className="h-4 w-20" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="mb-3">
      <CardContent className="p-4">
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="text-center p-3 bg-green-50 rounded-lg">
            <i className="fas fa-arrow-down text-green-600 mb-2 text-lg" />
            <p className="text-xs text-muted-foreground">Bu Ay Gelir</p>
            <p 
              className="font-semibold"
              style={{ color: 'hsl(142.1 76.2% 36.3%)' }}
              data-testid="monthly-income"
            >
              {formatCurrency(summary.totalIncome || 24500)}
            </p>
          </div>
          <div className="text-center p-3 bg-red-50 rounded-lg">
            <i className="fas fa-arrow-up text-red-600 mb-2 text-lg" />
            <p className="text-xs text-muted-foreground">Bu Ay Gider</p>
            <p 
              className="font-semibold"
              style={{ color: 'hsl(0 84.2% 60.2%)' }}
              data-testid="monthly-expenses"
            >
              {formatCurrency(summary.totalExpenses || 18750)}
            </p>
          </div>
        </div>
        
        <div className="space-y-3">
          {mockIncomeData.map((item) => (
            <div 
              key={item.type} 
              className="flex items-center justify-between py-2 border-b border-border"
              data-testid={`income-${item.type}`}
            >
              <div className="flex items-center space-x-3">
                <div className={`w-6 h-6 bg-${item.color}-100 rounded flex items-center justify-center`}>
                  <i className={`${item.icon} text-${item.color}-600 text-xs`} />
                </div>
                <span className="text-sm">{item.label}</span>
              </div>
              <span 
                className="text-sm font-medium"
                style={{ color: 'hsl(142.1 76.2% 36.3%)' }}
              >
                {formatCurrency(item.amount)}
              </span>
            </div>
          ))}
          
          {mockExpenseData.map((item) => (
            <div 
              key={item.type} 
              className="flex items-center justify-between py-2 border-b border-border last:border-b-0"
              data-testid={`expense-${item.type}`}
            >
              <div className="flex items-center space-x-3">
                <div className={`w-6 h-6 bg-${item.color}-100 rounded flex items-center justify-center`}>
                  <i className={`${item.icon} text-${item.color}-600 text-xs`} />
                </div>
                <span className="text-sm">{item.label}</span>
              </div>
              <span 
                className="text-sm font-medium"
                style={{ color: 'hsl(0 84.2% 60.2%)' }}
              >
                {formatCurrency(item.amount)}
              </span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
