import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import type { PortfolioAssetWithDetails } from "@/types/portfolio";

interface AssetCategoryProps {
  category: {
    id: string;
    name: string;
    icon: string;
  };
  assets: PortfolioAssetWithDetails[];
}

export function AssetCategory({ category, assets }: AssetCategoryProps) {
  const [isOpen, setIsOpen] = useState(true);

  const categoryValue = assets.reduce((sum, asset) => sum + asset.currentValue, 0);
  const categoryProfitLoss = assets.reduce((sum, asset) => sum + asset.profitLoss, 0);
  const categoryProfitLossPercent = assets.reduce((sum, asset) => {
    const invested = parseFloat(asset.totalInvested);
    return invested > 0 ? sum + ((asset.profitLoss / invested) * 100) : sum;
  }, 0) / assets.length;

  const formatCurrency = (amount: number, currency = "TRY") => {
    return new Intl.NumberFormat('tr-TR', {
      style: 'currency',
      currency,
      minimumFractionDigits: 2,
    }).format(amount);
  };

  const isPositive = categoryProfitLoss >= 0;

  return (
    <Card className="mb-3 overflow-hidden">
      <Collapsible open={isOpen} onOpenChange={setIsOpen}>
        <CollapsibleTrigger className="w-full">
          <div className="p-3 border-b border-border flex items-center justify-between hover:bg-secondary/50 transition-colors">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <i className={`${category.icon} text-primary-foreground text-xs`} />
              </div>
              <div className="text-left">
                <h4 className="font-medium" data-testid={`category-name-${category.id}`}>
                  {category.name}
                </h4>
                <p className="text-xs text-muted-foreground">
                  {assets.length} varlık
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="font-semibold" data-testid={`category-value-${category.id}`}>
                {formatCurrency(categoryValue)}
              </p>
              <p 
                className="text-xs"
                style={{ color: isPositive ? 'hsl(142.1 76.2% 36.3%)' : 'hsl(0 84.2% 60.2%)' }}
                data-testid={`category-change-${category.id}`}
              >
                {isPositive ? '+' : ''}{categoryProfitLossPercent.toFixed(2)}%
              </p>
            </div>
          </div>
        </CollapsibleTrigger>
        
        <CollapsibleContent>
          <div className="divide-y divide-border">
            {assets.map((asset) => {
              const assetIsPositive = asset.profitLoss >= 0;
              const assetData = asset.asset || { symbol: asset.assetId || 'N/A', name: 'Unknown Asset' };
              
              return (
                <div 
                  key={asset.id} 
                  className="p-3 flex items-center justify-between hover:bg-secondary/30 transition-colors"
                  data-testid={`asset-item-${assetData.symbol}`}
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-6 h-6 bg-blue-100 rounded flex items-center justify-center">
                      <span className="text-xs font-bold text-blue-800">
                        {assetData.symbol.charAt(0)}
                      </span>
                    </div>
                    <div>
                      <p className="font-medium text-sm" data-testid={`asset-symbol-${assetData.symbol}`}>
                        {assetData.symbol}
                      </p>
                      <p className="text-xs text-muted-foreground" data-testid={`asset-name-${assetData.symbol}`}>
                        {assetData.name}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold" data-testid={`asset-value-${assetData.symbol}`}>
                      {formatCurrency(asset.currentValue)}
                    </p>
                    <p 
                      className="text-xs"
                      style={{ color: assetIsPositive ? 'hsl(142.1 76.2% 36.3%)' : 'hsl(0 84.2% 60.2%)' }}
                      data-testid={`asset-change-${assetData.symbol}`}
                    >
                      {assetIsPositive ? '+' : ''}{asset.profitLossPercent.toFixed(1)}%
                    </p>
                  </div>
                </div>
              );
            })
          </div>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
}
