import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAssetCategories, useAssetSearch } from "@/hooks/use-assets";
import { useAddPortfolioAsset } from "@/hooks/use-portfolio";
import { useToast } from "@/hooks/use-toast";

const addAssetFormSchema = z.object({
  quantity: z.string()
    .min(1, "Alım miktarı girilmesi zorunludur")
    .refine(val => !isNaN(Number(val)) && Number(val) > 0, "Geçerli bir miktar giriniz"),
  price: z.string()
    .min(1, "Alım fiyatı girilmesi zorunludur")
    .refine(val => !isNaN(Number(val)) && Number(val) > 0, "Geçerli bir fiyat giriniz"),
  purchaseCurrency: z.enum(["USD", "TRY"], {
    required_error: "Para birimi seçiniz"
  }),
  purchaseDate: z.string()
    .min(1, "Alım tarihi girilmesi zorunludur")
    .refine(val => !isNaN(Date.parse(val)), "Geçerli bir tarih giriniz"),
  exchangeRate: z.string()
    .min(1, "USD/TRY kuru girilmesi zorunludur")
    .refine(val => !isNaN(Number(val)) && Number(val) > 0, "Geçerli bir kur giriniz"),
});

type AddAssetFormData = z.infer<typeof addAssetFormSchema>;

interface AddAssetModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AddAssetModal({ isOpen, onClose }: AddAssetModalProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedAsset, setSelectedAsset] = useState<any | null>(null);
  const [showForm, setShowForm] = useState(false);
  
  const { data: categories } = useAssetCategories();
  const { data: searchResults } = useAssetSearch(searchQuery);
  const addAssetMutation = useAddPortfolioAsset();
  const { toast } = useToast();

  const form = useForm<AddAssetFormData>({
    resolver: zodResolver(addAssetFormSchema),
    defaultValues: {
      quantity: "",
      price: "",
      purchaseCurrency: "USD",
      purchaseDate: new Date().toISOString().split('T')[0], // Today's date
      exchangeRate: "32.50", // Default USD/TRY rate
    },
  });

  const handleClose = () => {
    setSearchQuery("");
    setSelectedCategory(null);
    setSelectedAsset(null);
    setShowForm(false);
    form.reset();
    onClose();
  };

  const handleSelectAsset = async (asset: any) => {
    setSelectedAsset(asset);
    
    // Pre-fill form with smart defaults
    form.setValue('quantity', '1');
    form.setValue('price', '0');
    form.setValue('purchaseCurrency', 'USD');
    form.setValue('purchaseDate', new Date().toISOString().split('T')[0]);
    
    // Try to fetch current exchange rate
    try {
      const response = await fetch('/api/fx/USDTRY');
      if (response.ok) {
        const data = await response.json();
        form.setValue('exchangeRate', data.rate.toFixed(2));
      } else {
        form.setValue('exchangeRate', '32.50'); // fallback
      }
    } catch (error) {
      form.setValue('exchangeRate', '32.50'); // fallback
    }
    
    setShowForm(true);
  };

  const handleFormSubmit = async (data: AddAssetFormData) => {
    if (!selectedAsset) return;
    
    const quantity = parseFloat(data.quantity);
    const price = parseFloat(data.price);
    const exchangeRate = parseFloat(data.exchangeRate);
    
    // Calculate total amount in TRY based on purchase currency
    const totalAmountTRY = data.purchaseCurrency === "USD" 
      ? quantity * price * exchangeRate  // USD to TRY conversion
      : quantity * price; // Already in TRY
    
    try {
      await addAssetMutation.mutateAsync({
        assetId: selectedAsset.symbol, // Backend expects camelCase for Zod validation
        quantity: data.quantity,
        averagePurchasePrice: data.price,
        purchaseCurrency: data.purchaseCurrency,
        totalInvested: totalAmountTRY.toString(),
        purchaseDate: data.purchaseDate,
        exchangeRate: data.exchangeRate
      });
      
      toast({
        title: "Başarılı",
        description: "Varlık portföyünüze eklendi"
      });
      
      handleClose();
    } catch (error) {
      toast({
        title: "Hata",
        description: "Varlık eklenirken bir hata oluştu",
        variant: "destructive"
      });
    }
  };

  const handleBackToSearch = () => {
    setSelectedAsset(null);
    setShowForm(false);
    form.reset();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-sm mx-auto max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {showForm ? (
              <div className="flex items-center space-x-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleBackToSearch}
                  className="p-1"
                  data-testid="button-back-to-search"
                >
                  <i className="fas fa-arrow-left" />
                </Button>
                <span>Varlık Detayları</span>
              </div>
            ) : (
              "Varlık Ekle"
            )}
          </DialogTitle>
        </DialogHeader>
        
        {showForm ? (
          /* Form Content */
          <div className="space-y-4">
            {/* Selected Asset Info */}
            <div className="p-3 bg-secondary rounded-lg">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="text-sm font-bold text-blue-800">
                    {selectedAsset?.symbol?.charAt(0)}
                  </span>
                </div>
                <div>
                  <p className="font-medium">{selectedAsset?.symbol}</p>
                  <p className="text-sm text-muted-foreground">{selectedAsset?.name}</p>
                </div>
              </div>
            </div>

            {/* Add Asset Form */}
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-4">
                <div className="grid grid-cols-2 gap-2">
                  <FormField
                    control={form.control}
                    name="quantity"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Miktar</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step="any"
                            placeholder="1"
                            data-testid="input-quantity"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="price"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Fiyat</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step="any"
                            placeholder="0.00"
                            data-testid="input-price"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="purchaseCurrency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Para Birimi</FormLabel>
                      <FormControl>
                        <Select
                          value={field.value}
                          onValueChange={field.onChange}
                          data-testid="select-currency"
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="USD">USD</SelectItem>
                            <SelectItem value="TRY">TRY</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Advanced fields - collapsible */}
                <details className="space-y-3">
                  <summary className="cursor-pointer text-sm text-muted-foreground hover:text-foreground">
                    Gelişmiş Ayarlar
                  </summary>
                  <div className="space-y-3 mt-3">
                    <FormField
                      control={form.control}
                      name="purchaseDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Alım Tarihi</FormLabel>
                          <FormControl>
                            <Input
                              type="date"
                              data-testid="input-purchase-date"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="exchangeRate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>USD/TRY Kuru</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="0.01"
                              placeholder="32.50"
                              data-testid="input-exchange-rate"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </details>

                {/* Total Investment Display */}
                {form.watch("quantity") && form.watch("price") && form.watch("purchaseCurrency") && (
                  <div className="p-3 bg-blue-50 dark:bg-blue-950 rounded-lg space-y-2">
                    {form.watch("purchaseCurrency") === "USD" ? (
                      // USD to TRY conversion display
                      <>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-muted-foreground">USD Toplam:</span>
                          <span className="font-medium text-blue-700 dark:text-blue-300">
                            ${(
                              parseFloat(form.watch("quantity") || "0") * 
                              parseFloat(form.watch("price") || "0")
                            ).toFixed(2)}
                          </span>
                        </div>
                        {form.watch("exchangeRate") && (
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-muted-foreground">TRY Toplam:</span>
                            <span className="font-semibold text-blue-700 dark:text-blue-300">
                              {new Intl.NumberFormat('tr-TR', {
                                style: 'currency',
                                currency: 'TRY',
                                minimumFractionDigits: 2,
                              }).format(
                                parseFloat(form.watch("quantity") || "0") * 
                                parseFloat(form.watch("price") || "0") * 
                                parseFloat(form.watch("exchangeRate") || "0")
                              )}
                            </span>
                          </div>
                        )}
                      </>
                    ) : (
                      // TRY direct display
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">TRY Toplam:</span>
                        <span className="font-semibold text-blue-700 dark:text-blue-300">
                          {new Intl.NumberFormat('tr-TR', {
                            style: 'currency',
                            currency: 'TRY',
                            minimumFractionDigits: 2,
                          }).format(
                            parseFloat(form.watch("quantity") || "0") * 
                            parseFloat(form.watch("price") || "0")
                          )}
                        </span>
                      </div>
                    )}
                  </div>
                )}

                <div className="flex space-x-2 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleBackToSearch}
                    className="flex-1"
                    data-testid="button-cancel-add"
                  >
                    İptal
                  </Button>
                  <Button
                    type="submit"
                    className="flex-1 bg-blue-600 hover:bg-blue-700"
                    disabled={addAssetMutation.isPending || !form.watch("quantity") || !form.watch("price")}
                    data-testid="button-submit-add"
                  >
                    {addAssetMutation.isPending ? (
                      <>
                        <i className="fas fa-spinner fa-spin mr-2" />
                        Ekleniyor...
                      </>
                    ) : (
                      <>
                        <i className="fas fa-plus mr-2" />
                        Hızlı Ekle
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </Form>
          </div>
        ) : (
          /* Search Content */
          <div className="space-y-4">
          {/* Search Input */}
          <div className="relative">
            <Input
              type="text"
              placeholder="Hisse, kripto, altın ara..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-10"
              data-testid="asset-search-input"
            />
            <i className="fas fa-search absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
          </div>
          
          {/* Asset Categories */}
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              {categories?.map((category) => (
                <Button
                  key={category.id}
                  variant="outline"
                  className="flex items-center space-x-3 p-3 h-auto"
                  onClick={() => setSelectedCategory(category.id)}
                  data-testid={`category-button-${category.id}`}
                >
                  <i className={`${category.icon} text-blue-600`} />
                  <span className="text-sm">{category.name}</span>
                </Button>
              ))}
            </div>
          </div>
          
          {/* Search Results */}
          {searchResults && searchResults.length > 0 && (
            <div>
              <h4 className="font-medium mb-3 text-sm text-muted-foreground">Arama Sonuçları</h4>
              <div className="space-y-2">
                {searchResults.map((asset) => (
                  <div
                    key={asset.symbol}
                    className="flex items-center justify-between p-3 rounded-lg border border-border cursor-pointer hover:bg-secondary transition-colors"
                    onClick={() => handleSelectAsset(asset)}
                    data-testid={`search-result-${asset.symbol}`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <span className="text-xs font-bold text-blue-800">
                          {asset.symbol.charAt(0)}
                        </span>
                      </div>
                      <div>
                        <p className="font-medium text-sm">{asset.symbol}</p>
                        <p className="text-xs text-muted-foreground">{asset.name}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-muted-foreground">{asset.exchange}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* Popular Assets - Mock data for demo */}
          {!searchQuery && (
            <div>
              <h4 className="font-medium mb-3 text-sm text-muted-foreground">Popüler Varlıklar</h4>
              <div className="space-y-2">
                {[
                  { symbol: "AAPL", name: "Apple Inc.", price: "$175.84", change: "+2.1%" },
                  { symbol: "TSLA", name: "Tesla Inc.", price: "$242.65", change: "-1.2%" },
                  { symbol: "BTC", name: "Bitcoin", price: "$43,250", change: "+3.5%" },
                  { symbol: "ETH", name: "Ethereum", price: "$2,650", change: "+2.8%" }
                ].map((asset) => (
                  <div
                    key={asset.symbol}
                    className="flex items-center justify-between p-3 rounded-lg border border-border cursor-pointer hover:bg-secondary transition-colors"
                    onClick={() => handleSelectAsset(asset)}
                    data-testid={`popular-asset-${asset.symbol}`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <span className="text-xs font-bold text-blue-800">
                          {asset.symbol.charAt(0)}
                        </span>
                      </div>
                      <div>
                        <p className="font-medium text-sm">{asset.symbol}</p>
                        <p className="text-xs text-muted-foreground">{asset.name}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-semibold">{asset.price}</p>
                      <p 
                        className="text-xs"
                        style={{ 
                          color: asset.change.startsWith('+') 
                            ? 'hsl(142.1 76.2% 36.3%)' 
                            : 'hsl(0 84.2% 60.2%)' 
                        }}
                      >
                        {asset.change}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
