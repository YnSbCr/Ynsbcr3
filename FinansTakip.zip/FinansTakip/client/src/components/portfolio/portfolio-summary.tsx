import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { XAxis, YAxis, ResponsiveContainer, Area, AreaChart } from "recharts";
import type { PortfolioSummary } from "@/types/portfolio";

// Mock data for performance chart - in real app this would come from API
const mockChartData = {
  "1D": [
    { name: "09:00", value: 485000 },
    { name: "11:00", value: 488000 },
    { name: "13:00", value: 482000 },
    { name: "15:00", value: 487642 },
    { name: "17:00", value: 489500 },
  ],
  "1W": [
    { name: "Pzt", value: 450000 },
    { name: "Sal", value: 465000 },
    { name: "Çar", value: 452000 },
    { name: "Per", value: 478000 },
    { name: "Cum", value: 475000 },
    { name: "Cmt", value: 485000 },
    { name: "Paz", value: 487642 },
  ],
  "1M": [
    { name: "Hft 1", value: 420000 },
    { name: "Hft 2", value: 435000 },
    { name: "Hft 3", value: 451000 },
    { name: "Hft 4", value: 487642 },
  ],
  "3M": [
    { name: "Oca", value: 380000 },
    { name: "Şub", value: 405000 },
    { name: "Mar", value: 487642 },
  ],
  "YTD": [
    { name: "Oca", value: 320000 },
    { name: "Şub", value: 365000 },
    { name: "Mar", value: 487642 },
  ],
  "5Y": [
    { name: "2020", value: 180000 },
    { name: "2021", value: 225000 },
    { name: "2022", value: 290000 },
    { name: "2023", value: 380000 },
    { name: "2024", value: 487642 },
  ]
};

const timeframeLabels = {
  "1D": "Günlük",
  "1W": "Haftalık",
  "1M": "Aylık", 
  "3M": "3 Aylık",
  "YTD": "Yılbaşından",
  "5Y": "5 Yıllık"
};

interface PortfolioSummaryProps {
  summary: PortfolioSummary;
  isLoading?: boolean;
}

export function PortfolioSummaryCard({ summary, isLoading }: PortfolioSummaryProps) {
  const [selectedTimeframe, setSelectedTimeframe] = useState<keyof typeof mockChartData>("1W");

  const data = mockChartData[selectedTimeframe];
  
  // Calculate performance direction for color
  const chartIsPositive = data.length > 1 ? data[data.length - 1].value >= data[0].value : true;
  const colorScheme = chartIsPositive 
    ? { 
        stroke: "hsl(142.1 76.2% 36.3%)", // Green
        fill: "hsl(142.1 76.2% 36.3%)",
        gradientId: "colorValuePositive"
      }
    : { 
        stroke: "hsl(0 84.2% 60.2%)", // Red
        fill: "hsl(0 84.2% 60.2%)",
        gradientId: "colorValueNegative"
      };

  // Calculate percentage change for chart
  const chartPercentageChange = data.length > 1 
    ? ((data[data.length - 1].value - data[0].value) / data[0].value * 100)
    : 0;

  if (isLoading) {
    return (
      <Card className="mb-4">
        <CardContent className="p-4">
          <div className="text-center">
            <Skeleton className="h-4 w-32 mx-auto mb-2" />
            <Skeleton className="h-8 w-40 mx-auto mb-2" />
            <Skeleton className="h-6 w-36 mx-auto mb-2" />
            <Skeleton className="h-3 w-20 mx-auto" />
          </div>
          <div className="mt-4 pt-4 border-t border-border">
            <Skeleton className="h-48 w-full mb-4" />
            <div className="flex flex-wrap gap-2 justify-center">
              <Skeleton className="h-8 w-16" />
              <Skeleton className="h-8 w-16" />
              <Skeleton className="h-8 w-16" />
              <Skeleton className="h-8 w-16" />
              <Skeleton className="h-8 w-20" />
              <Skeleton className="h-8 w-16" />
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('tr-TR', {
      style: 'currency',
      currency: summary.currency,
      minimumFractionDigits: 2,
    }).format(amount);
  };

  const formatUSD = (amountTRY: number) => {
    const usdRate = 32.50; // Current USD/TRY rate - can be made dynamic later
    const usdAmount = amountTRY / usdRate;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(usdAmount);
  };


  return (
    <Card className="mb-4">
      <CardContent className="p-4">
        <div className="text-center">
          <h2 className="text-sm text-muted-foreground mb-1">Toplam Portföy Değeri</h2>
          <div className="space-y-1 mb-1">
            <p className="text-2xl font-bold" data-testid="total-portfolio-value">
              {formatCurrency(summary.totalValue)}
            </p>
            <p className="text-sm text-muted-foreground" data-testid="total-portfolio-value-usd">
              {formatUSD(summary.totalValue)}
            </p>
          </div>
          <div className="flex items-center justify-center space-x-1">
            <i 
              className={`fas ${chartIsPositive ? 'fa-arrow-up' : 'fa-arrow-down'} text-xs`}
              style={{ color: chartIsPositive ? 'hsl(142.1 76.2% 36.3%)' : 'hsl(0 84.2% 60.2%)' }}
            />
            <span 
              className="text-sm font-medium"
              style={{ color: chartIsPositive ? 'hsl(142.1 76.2% 36.3%)' : 'hsl(0 84.2% 60.2%)' }}
              data-testid="timeframe-change"
            >
              {chartIsPositive ? '+' : ''}{chartPercentageChange.toFixed(2)}% ({timeframeLabels[selectedTimeframe]})
            </span>
          </div>
          <p className="text-xs text-muted-foreground mt-1">Toplam Kar/Zarar</p>
        </div>
        

        {/* Performance Chart Section */}
        <div className="mt-4 pt-4 border-t border-border">
          <div className="h-48 w-full" data-testid="performance-chart">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorValuePositive" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(142.1 76.2% 36.3%)" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="hsl(142.1 76.2% 36.3%)" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorValueNegative" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(0 84.2% 60.2%)" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="hsl(0 84.2% 60.2%)" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis 
                  dataKey="name" 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12, fill: 'hsl(215.4 16.3% 46.9%)' }}
                />
                <YAxis 
                  hide
                  domain={['dataMin - 10000', 'dataMax + 10000']}
                />
                <Area
                  type="monotone"
                  dataKey="value"
                  stroke={colorScheme.stroke}
                  strokeWidth={2}
                  fill={`url(#${colorScheme.gradientId})`}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          
          <div className="flex justify-between text-xs text-muted-foreground mt-2">
            <span>Başlangıç</span>
            <span>Bugün</span>
          </div>
          
          {/* Timeframe Buttons */}
          <div className="flex flex-wrap gap-2 mt-4 justify-center">
            {Object.keys(timeframeLabels).map((timeframe) => (
              <Button
                key={timeframe}
                variant={selectedTimeframe === timeframe ? "default" : "secondary"}
                size="sm"
                onClick={() => setSelectedTimeframe(timeframe as keyof typeof mockChartData)}
                className="text-xs px-2 py-1 min-w-0"
                data-testid={`timeframe-${timeframe}`}
              >
                {timeframeLabels[timeframe as keyof typeof timeframeLabels]}
              </Button>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
