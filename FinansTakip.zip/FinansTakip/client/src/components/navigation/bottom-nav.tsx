import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

interface BottomNavProps {
  onAddAsset: () => void;
}

export function BottomNav({ onAddAsset }: BottomNavProps) {
  const [location, navigate] = useLocation();

  const navItems = [
    { id: 'home', label: 'Ana Sayfa', icon: 'fas fa-home', path: '/' },
    { id: 'portfolio', label: 'Portföy', icon: 'fas fa-briefcase', path: '/portfolio' },
    { id: 'add', label: 'Ekle', icon: 'fas fa-plus', isAdd: true, path: undefined },
    { id: 'transactions', label: 'İşlemler', icon: 'fas fa-exchange-alt', path: '/transactions' },
    { id: 'profile', label: 'Profil', icon: 'fas fa-user', path: '/profile' }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border px-4 py-2 flex items-center justify-around z-50">
      {navItems.map((item) => (
        <div key={item.id} className="flex flex-col items-center">
          {item.isAdd ? (
            <Button
              onClick={onAddAsset}
              className="w-12 h-12 rounded-full bg-primary hover:bg-primary/90 shadow-lg flex items-center justify-center"
              data-testid="button-add-asset"
            >
              <span className="text-xl font-bold text-primary-foreground">+</span>
            </Button>
          ) : (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => item.path && navigate(item.path)}
              className="flex flex-col items-center space-y-1 px-2 py-1 h-auto min-h-0"
              data-testid={`nav-${item.id}`}
            >
              <i 
                className={`${item.icon} text-lg ${location === item.path ? 'text-primary' : 'text-muted-foreground'}`} 
              />
              <span 
                className={`text-xs ${location === item.path ? 'text-primary font-medium' : 'text-muted-foreground'}`}
              >
                {item.label}
              </span>
            </Button>
          )}
        </div>
      ))}
    </nav>
  );
}