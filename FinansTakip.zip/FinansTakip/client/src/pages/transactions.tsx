import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { tr } from "date-fns/locale";

interface Transaction {
  id: string;
  type: "buy" | "sell";
  quantity: string;
  price: string;
  totalAmount: string;
  currency: string;
  date: string;
  asset: {
    symbol: string;
    name: string;
  };
}

export default function Transactions() {
  const { data: transactions, isLoading } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
  });

  const formatCurrency = (amount: string, currency: string) => {
    return new Intl.NumberFormat('tr-TR', {
      style: 'currency',
      currency,
      minimumFractionDigits: 2,
    }).format(parseFloat(amount));
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-card border-b border-border px-4 py-3 flex items-center justify-between">
        <h1 className="text-lg font-semibold">İşlemler</h1>
        <Button size="sm" data-testid="button-add-transaction">
          <i className="fas fa-plus text-sm mr-2" />
          İşlem Ekle
        </Button>
      </header>

      <main className="p-4">
        {/* Transaction Stats */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-muted-foreground">Bu Ay Alım</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-lg font-semibold text-success" data-testid="monthly-buys">
                ₺0.00
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-muted-foreground">Bu Ay Satım</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-lg font-semibold text-destructive" data-testid="monthly-sells">
                ₺0.00
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Transactions List */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Son İşlemler</h3>
          
          {isLoading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <Card key={i}>
                  <CardContent className="p-4">
                    <div className="animate-pulse">
                      <div className="flex justify-between items-start">
                        <div className="space-y-2">
                          <div className="h-4 bg-muted rounded w-24" />
                          <div className="h-3 bg-muted rounded w-32" />
                        </div>
                        <div className="text-right space-y-2">
                          <div className="h-4 bg-muted rounded w-20" />
                          <div className="h-3 bg-muted rounded w-16" />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : transactions && transactions.length > 0 ? (
            <div className="space-y-3">
              {transactions.map((transaction) => (
                <Card key={transaction.id} data-testid={`transaction-${transaction.id}`}>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <Badge 
                            variant={transaction.type === "buy" ? "default" : "destructive"}
                            className="text-xs"
                          >
                            {transaction.type === "buy" ? "ALIM" : "SATIM"}
                          </Badge>
                          <span className="font-medium">{transaction.asset.symbol}</span>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {transaction.asset.name}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {parseFloat(transaction.quantity).toLocaleString('tr-TR')} adet × {formatCurrency(transaction.price, transaction.currency)}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {format(new Date(transaction.date), 'dd MMM yyyy HH:mm', { locale: tr })}
                        </p>
                      </div>
                      <div className="text-right">
                        <p 
                          className="font-semibold"
                          style={{ 
                            color: transaction.type === "buy" 
                              ? 'hsl(0 84.2% 60.2%)' 
                              : 'hsl(142.1 76.2% 36.3%)' 
                          }}
                        >
                          {transaction.type === "buy" ? '-' : '+'}
                          {formatCurrency(transaction.totalAmount, transaction.currency)}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <i className="fas fa-exchange-alt text-4xl text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Henüz işlem geçmişiniz bulunmuyor</p>
              <Button className="mt-4" data-testid="button-first-transaction">
                İlk İşleminizi Yapın
              </Button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
