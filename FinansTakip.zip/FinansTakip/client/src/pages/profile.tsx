import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { usePortfolio } from "@/hooks/use-portfolio";

export default function Profile() {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: "Mehmet Yılmaz",
    email: "mehmet@example.com",
    phone: "+90 532 123 45 67",
    preferredCurrency: "TRY",
    notifications: {
      priceAlerts: true,
      portfolioUpdates: true,
      marketNews: false,
      weeklyReports: true
    }
  });

  const { data: portfolioData } = usePortfolio();

  const handleSave = () => {
    // In a real app, this would call an API to update the user profile
    setIsEditing(false);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('tr-TR', {
      style: 'currency',
      currency: 'TRY',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-card border-b border-border px-4 py-3 flex items-center justify-between">
        <h1 className="text-lg font-semibold">Profil</h1>
        <Button 
          variant={isEditing ? "default" : "outline"}
          size="sm"
          onClick={isEditing ? handleSave : () => setIsEditing(true)}
          data-testid="edit-profile-button"
        >
          {isEditing ? (
            <>
              <i className="fas fa-check text-sm mr-2" />
              Kaydet
            </>
          ) : (
            <>
              <i className="fas fa-edit text-sm mr-2" />
              Düzenle
            </>
          )}
        </Button>
      </header>

      <main className="p-4">
        <Tabs defaultValue="profile" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="profile" data-testid="tab-profile">Profil</TabsTrigger>
            <TabsTrigger value="settings" data-testid="tab-settings">Ayarlar</TabsTrigger>
            <TabsTrigger value="about" data-testid="tab-about">Hakkında</TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="space-y-4">
            {/* Profile Header */}
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center space-x-4">
                  <Avatar className="h-16 w-16" data-testid="user-avatar">
                    <AvatarFallback className="text-xl font-bold">
                      {formData.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <h2 className="text-xl font-bold" data-testid="user-name">
                      {formData.name}
                    </h2>
                    <p className="text-muted-foreground" data-testid="user-email">
                      {formData.email}
                    </p>
                    <div className="flex items-center space-x-2 mt-2">
                      <Badge variant="secondary">Premium Üye</Badge>
                      <Badge variant="outline">Aktif</Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Personal Information */}
            <Card>
              <CardHeader>
                <CardTitle>Kişisel Bilgiler</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 gap-4">
                  <div>
                    <Label htmlFor="name">Ad Soyad</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      disabled={!isEditing}
                      data-testid="input-name"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="email">E-posta</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      disabled={!isEditing}
                      data-testid="input-email"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="phone">Telefon</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => setFormData({...formData, phone: e.target.value})}
                      disabled={!isEditing}
                      data-testid="input-phone"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="currency">Varsayılan Para Birimi</Label>
                    <Select 
                      value={formData.preferredCurrency} 
                      onValueChange={(value) => setFormData({...formData, preferredCurrency: value})}
                      disabled={!isEditing}
                    >
                      <SelectTrigger data-testid="select-currency">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="TRY">Türk Lirası (₺)</SelectItem>
                        <SelectItem value="USD">Amerikan Doları ($)</SelectItem>
                        <SelectItem value="EUR">Euro (€)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Portfolio Stats */}
            <Card>
              <CardHeader>
                <CardTitle>Portföy İstatistikleri</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-secondary/20 rounded-lg">
                    <p className="text-2xl font-bold" data-testid="total-assets">
                      {portfolioData?.assets.length || 0}
                    </p>
                    <p className="text-xs text-muted-foreground">Toplam Varlık</p>
                  </div>
                  
                  <div className="text-center p-3 bg-secondary/20 rounded-lg">
                    <p className="text-2xl font-bold" data-testid="portfolio-age">
                      {Math.floor(Math.random() * 12) + 1}
                    </p>
                    <p className="text-xs text-muted-foreground">Ay Yaşında</p>
                  </div>
                  
                  <div className="text-center p-3 bg-secondary/20 rounded-lg">
                    <p 
                      className="text-2xl font-bold"
                      style={{ 
                        color: (portfolioData?.summary.totalProfitLossPercent || 0) >= 0 
                          ? 'hsl(142.1 76.2% 36.3%)' 
                          : 'hsl(0 84.2% 60.2%)' 
                      }}
                      data-testid="best-performance"
                    >
                      +{Math.floor(Math.random() * 50) + 10}%
                    </p>
                    <p className="text-xs text-muted-foreground">En İyi Performans</p>
                  </div>
                  
                  <div className="text-center p-3 bg-secondary/20 rounded-lg">
                    <p className="text-2xl font-bold" data-testid="transaction-count">
                      {Math.floor(Math.random() * 100) + 20}
                    </p>
                    <p className="text-xs text-muted-foreground">Toplam İşlem</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-4">
            {/* Notification Settings */}
            <Card>
              <CardHeader>
                <CardTitle>Bildirim Ayarları</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="price-alerts">Fiyat Uyarıları</Label>
                    <p className="text-sm text-muted-foreground">
                      Varlık fiyat değişimleri için bildirim alın
                    </p>
                  </div>
                  <Switch
                    id="price-alerts"
                    checked={formData.notifications.priceAlerts}
                    onCheckedChange={(checked) => 
                      setFormData({
                        ...formData, 
                        notifications: {...formData.notifications, priceAlerts: checked}
                      })
                    }
                    data-testid="switch-price-alerts"
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="portfolio-updates">Portföy Güncellemeleri</Label>
                    <p className="text-sm text-muted-foreground">
                      Portföy değeri değişimleri için bildirim alın
                    </p>
                  </div>
                  <Switch
                    id="portfolio-updates"
                    checked={formData.notifications.portfolioUpdates}
                    onCheckedChange={(checked) => 
                      setFormData({
                        ...formData, 
                        notifications: {...formData.notifications, portfolioUpdates: checked}
                      })
                    }
                    data-testid="switch-portfolio-updates"
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="market-news">Piyasa Haberleri</Label>
                    <p className="text-sm text-muted-foreground">
                      Günlük piyasa analizi ve haberleri alın
                    </p>
                  </div>
                  <Switch
                    id="market-news"
                    checked={formData.notifications.marketNews}
                    onCheckedChange={(checked) => 
                      setFormData({
                        ...formData, 
                        notifications: {...formData.notifications, marketNews: checked}
                      })
                    }
                    data-testid="switch-market-news"
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="weekly-reports">Haftalık Raporlar</Label>
                    <p className="text-sm text-muted-foreground">
                      Haftalık performans özeti alın
                    </p>
                  </div>
                  <Switch
                    id="weekly-reports"
                    checked={formData.notifications.weeklyReports}
                    onCheckedChange={(checked) => 
                      setFormData({
                        ...formData, 
                        notifications: {...formData.notifications, weeklyReports: checked}
                      })
                    }
                    data-testid="switch-weekly-reports"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Security Settings */}
            <Card>
              <CardHeader>
                <CardTitle>Güvenlik</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button variant="outline" className="w-full justify-start" data-testid="change-password">
                  <i className="fas fa-key mr-3" />
                  Şifre Değiştir
                </Button>
                
                <Button variant="outline" className="w-full justify-start" data-testid="enable-2fa">
                  <i className="fas fa-shield-alt mr-3" />
                  İki Faktörlü Kimlik Doğrulama
                </Button>
                
                <Button variant="outline" className="w-full justify-start" data-testid="login-history">
                  <i className="fas fa-history mr-3" />
                  Giriş Geçmişi
                </Button>
              </CardContent>
            </Card>

            {/* Data Management */}
            <Card>
              <CardHeader>
                <CardTitle>Veri Yönetimi</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button variant="outline" className="w-full justify-start" data-testid="export-data">
                  <i className="fas fa-download mr-3" />
                  Verilerimi İndir
                </Button>
                
                <Button variant="outline" className="w-full justify-start" data-testid="backup-portfolio">
                  <i className="fas fa-cloud-upload-alt mr-3" />
                  Portföyü Yedekle
                </Button>
                
                <Separator />
                
                <Button variant="destructive" className="w-full justify-start" data-testid="delete-account">
                  <i className="fas fa-trash mr-3" />
                  Hesabımı Sil
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="about" className="space-y-4">
            {/* App Information */}
            <Card>
              <CardHeader>
                <CardTitle>Uygulama Bilgileri</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Versiyon</span>
                  <span className="font-medium" data-testid="app-version">1.0.0</span>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Son Güncelleme</span>
                  <span className="font-medium">15 Aralık 2024</span>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Geliştirici</span>
                  <span className="font-medium">Portföy Takip A.Ş.</span>
                </div>
              </CardContent>
            </Card>

            {/* Support & Legal */}
            <Card>
              <CardHeader>
                <CardTitle>Destek & Yasal</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button variant="outline" className="w-full justify-start" data-testid="help-center">
                  <i className="fas fa-question-circle mr-3" />
                  Yardım Merkezi
                </Button>
                
                <Button variant="outline" className="w-full justify-start" data-testid="contact-support">
                  <i className="fas fa-envelope mr-3" />
                  Destek Ekibi
                </Button>
                
                <Button variant="outline" className="w-full justify-start" data-testid="privacy-policy">
                  <i className="fas fa-user-shield mr-3" />
                  Gizlilik Politikası
                </Button>
                
                <Button variant="outline" className="w-full justify-start" data-testid="terms-of-service">
                  <i className="fas fa-file-contract mr-3" />
                  Kullanım Şartları
                </Button>
                
                <Button variant="outline" className="w-full justify-start" data-testid="rate-app">
                  <i className="fas fa-star mr-3" />
                  Uygulamayı Değerlendir
                </Button>
              </CardContent>
            </Card>

            {/* Credits */}
            <Card>
              <CardContent className="pt-6 text-center">
                <i className="fas fa-chart-line text-4xl text-primary mb-4" />
                <h3 className="text-lg font-semibold mb-2">Portföy Takip</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Yatırımlarınızı takip etmenin en kolay yolu
                </p>
                <p className="text-xs text-muted-foreground">
                  © 2024 Portföy Takip A.Ş. Tüm hakları saklıdır.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
