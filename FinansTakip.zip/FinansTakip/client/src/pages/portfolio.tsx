import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { usePortfolio } from "@/hooks/use-portfolio";
import { AssetCategory } from "@/components/portfolio/asset-category";
import { AddAssetModal } from "@/components/portfolio/add-asset-modal";
import { BottomNav } from "@/components/navigation/bottom-nav";

export default function Portfolio() {
  const [isAddAssetModalOpen, setIsAddAssetModalOpen] = useState(false);
  const { data: portfolioData, isLoading } = usePortfolio();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('tr-TR', {
      style: 'currency',
      currency: 'TRY',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  const formatUSD = (amountTRY: number) => {
    const usdRate = 32.50; // Current USD/TRY rate - can be made dynamic later
    const usdAmount = amountTRY / usdRate;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(usdAmount);
  };

  // Group assets by category
  const assetsByCategory = portfolioData?.assets.reduce((acc, asset) => {
    const categoryId = asset.category?.id || 'uncategorized';
    if (!acc[categoryId]) {
      acc[categoryId] = {
        category: asset.category || { id: 'uncategorized', name: 'Diğer', icon: 'fas fa-question' },
        assets: []
      };
    }
    acc[categoryId].assets.push(asset);
    return acc;
  }, {} as Record<string, { category: any; assets: any[] }>) || {};

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-card border-b border-border px-4 py-3 flex items-center justify-between">
        <h1 className="text-lg font-semibold">Portföy</h1>
        <Button 
          onClick={() => setIsAddAssetModalOpen(true)}
          size="sm"
          data-testid="button-add-asset"
        >
          <i className="fas fa-plus text-sm mr-2" />
          Varlık Ekle
        </Button>
      </header>

      <main className="flex-1 overflow-y-auto scrollbar-thin pb-20 p-4">
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview" data-testid="tab-overview">Genel Bakış</TabsTrigger>
            <TabsTrigger value="assets" data-testid="tab-assets">Varlıklar</TabsTrigger>
            <TabsTrigger value="allocation" data-testid="tab-allocation">Dağılım</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-4">
            {/* Portfolio Summary Cards */}
            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm text-muted-foreground">Toplam Değer</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-1">
                    <p className="text-xl font-bold" data-testid="total-value">
                      {formatCurrency(portfolioData?.summary.totalValue || 0)}
                    </p>
                    <p className="text-sm text-muted-foreground" data-testid="total-value-usd">
                      {formatUSD(portfolioData?.summary.totalValue || 0)}
                    </p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm text-muted-foreground">Toplam Kar/Zarar</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-1">
                    <p 
                      className="text-xl font-bold"
                      style={{ 
                        color: (portfolioData?.summary.totalProfitLoss || 0) >= 0 
                          ? 'hsl(142.1 76.2% 36.3%)' 
                          : 'hsl(0 84.2% 60.2%)' 
                      }}
                      data-testid="total-profit-loss"
                    >
                      {formatCurrency(portfolioData?.summary.totalProfitLoss || 0)}
                    </p>
                    <p 
                      className="text-sm text-muted-foreground" 
                      data-testid="total-profit-loss-usd"
                    >
                      {formatUSD(portfolioData?.summary.totalProfitLoss || 0)}
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm text-muted-foreground">Yatırılan Tutar</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-1">
                    <p className="text-lg font-semibold" data-testid="total-invested">
                      {formatCurrency(portfolioData?.summary.totalInvested || 0)}
                    </p>
                    <p className="text-sm text-muted-foreground" data-testid="total-invested-usd">
                      {formatUSD(portfolioData?.summary.totalInvested || 0)}
                    </p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm text-muted-foreground">Getiri Oranı</CardTitle>
                </CardHeader>
                <CardContent>
                  <p 
                    className="text-lg font-semibold"
                    style={{ 
                      color: (portfolioData?.summary.totalProfitLossPercent || 0) >= 0 
                        ? 'hsl(142.1 76.2% 36.3%)' 
                        : 'hsl(0 84.2% 60.2%)' 
                    }}
                    data-testid="return-percentage"
                  >
                    {(portfolioData?.summary.totalProfitLossPercent || 0).toFixed(2)}%
                  </p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="assets" className="space-y-4">
            {Object.values(assetsByCategory).length > 0 ? (
              Object.values(assetsByCategory).map(({ category, assets }) => (
                <AssetCategory 
                  key={category.id} 
                  category={category} 
                  assets={assets} 
                />
              ))
            ) : (
              <div className="text-center py-8">
                <i className="fas fa-chart-pie text-4xl text-muted-foreground mb-4" />
                <p className="text-muted-foreground">Henüz portföyünüzde varlık bulunmuyor</p>
                <Button 
                  className="mt-4"
                  onClick={() => setIsAddAssetModalOpen(true)}
                >
                  İlk Varlığınızı Ekleyin
                </Button>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="allocation" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Portföy Dağılımı</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Object.values(assetsByCategory).map(({ category, assets }) => {
                    const categoryValue = assets.reduce((sum, asset) => sum + asset.currentValue, 0);
                    const percentage = portfolioData?.summary.totalValue 
                      ? (categoryValue / portfolioData.summary.totalValue) * 100 
                      : 0;
                    
                    return (
                      <div key={category.id} className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium">{category.name}</span>
                          <span className="text-sm text-muted-foreground">
                            {percentage.toFixed(1)}%
                          </span>
                        </div>
                        <div className="w-full bg-secondary rounded-full h-2">
                          <div 
                            className="bg-primary h-2 rounded-full transition-all"
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {formatCurrency(categoryValue)}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Bottom Navigation */}
      <BottomNav onAddAsset={() => setIsAddAssetModalOpen(true)} />

      <AddAssetModal 
        isOpen={isAddAssetModalOpen} 
        onClose={() => setIsAddAssetModalOpen(false)} 
      />
    </div>
  );
}
