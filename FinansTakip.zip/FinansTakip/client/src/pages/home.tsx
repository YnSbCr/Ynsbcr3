import { useState } from "react";
import { Button } from "@/components/ui/button";
import { PortfolioSummaryCard } from "@/components/portfolio/portfolio-summary";
import { AssetCategory } from "@/components/portfolio/asset-category";
import { AddAssetModal } from "@/components/portfolio/add-asset-modal";
import { IncomeExpenses } from "@/components/income/income-expenses";
import { BottomNav } from "@/components/navigation/bottom-nav";
import { usePortfolio } from "@/hooks/use-portfolio";

export default function Home() {
  const [isAddAssetModalOpen, setIsAddAssetModalOpen] = useState(false);
  const { data: portfolioData, isLoading } = usePortfolio();

  // Group assets by category
  const assetsByCategory = portfolioData?.assets.reduce((acc, asset) => {
    const categoryId = asset.category?.id || 'uncategorized';
    if (!acc[categoryId]) {
      acc[categoryId] = {
        category: asset.category || { id: 'uncategorized', name: 'Diğer', icon: 'fas fa-question' },
        assets: []
      };
    }
    acc[categoryId].assets.push(asset);
    return acc;
  }, {} as Record<string, { category: any; assets: any[] }>) || {};

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-card border-b border-border px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
            <i className="fas fa-chart-line text-primary-foreground text-sm" />
          </div>
          <div>
            <h1 className="text-lg font-semibold">Portföy Takip</h1>
            <p className="text-xs text-muted-foreground" data-testid="user-name">
              Mehmet Yılmaz
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <Button 
            variant="secondary" 
            size="sm" 
            className="w-8 h-8 rounded-full p-0"
            data-testid="button-notifications"
          >
            <i className="fas fa-bell text-sm" />
          </Button>
          <Button 
            variant="secondary" 
            size="sm" 
            className="w-8 h-8 rounded-full p-0"
            data-testid="button-settings"
          >
            <i className="fas fa-cog text-sm" />
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto scrollbar-thin pb-20">
        {/* Portfolio Summary */}
        <section className="p-4">
          <PortfolioSummaryCard 
            summary={portfolioData?.summary || {
              totalValue: 0,
              totalInvested: 0,
              totalProfitLoss: 0,
              totalProfitLossPercent: 0,
              currency: 'TRY'
            }} 
            isLoading={isLoading} 
          />
        </section>



        {/* Portfolio Breakdown */}
        <section className="px-4 mb-4">
          <h3 className="text-lg font-semibold mb-3">Portföy Dağılımı</h3>
          
          {Object.values(assetsByCategory).length > 0 ? (
            Object.values(assetsByCategory).map(({ category, assets }) => (
              <AssetCategory 
                key={category.id} 
                category={category} 
                assets={assets} 
              />
            ))
          ) : (
            !isLoading && (
              <div className="text-center py-8">
                <i className="fas fa-chart-pie text-4xl text-muted-foreground mb-4" />
                <p className="text-muted-foreground">Henüz portföyünüzde varlık bulunmuyor</p>
                <p className="text-sm text-muted-foreground mt-4">
                  Varlık eklemek için alttaki + butonunu kullanın
                </p>
              </div>
            )
          )}
        </section>

        {/* Income & Expenses */}
        <section className="px-4 mb-4">
          <h3 className="text-lg font-semibold mb-3">Gelir & Giderler</h3>
          <IncomeExpenses />
        </section>

      </main>

      {/* Bottom Navigation */}
      <BottomNav onAddAsset={() => setIsAddAssetModalOpen(true)} />

      {/* Add Asset Modal */}
      <AddAssetModal 
        isOpen={isAddAssetModalOpen} 
        onClose={() => setIsAddAssetModalOpen(false)} 
      />
    </div>
  );
}
