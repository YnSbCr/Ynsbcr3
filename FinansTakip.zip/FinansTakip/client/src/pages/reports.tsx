import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { usePortfolio } from "@/hooks/use-portfolio";
import { useIncomeExpenseSummary } from "@/hooks/use-financial-data";
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, LineChart, Line, Area, AreaChart } from "recharts";

export default function Reports() {
  const [selectedPeriod, setSelectedPeriod] = useState("monthly");
  const { data: portfolioData, isLoading } = usePortfolio();
  const incomeExpenseSummary = useIncomeExpenseSummary();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('tr-TR', {
      style: 'currency',
      currency: 'TRY',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  // Group assets by category for pie chart
  const categoryData = portfolioData?.assets.reduce((acc, asset) => {
    const categoryName = asset.category?.name || 'Diğer';
    const existing = acc.find(item => item.name === categoryName);
    if (existing) {
      existing.value += asset.currentValue;
    } else {
      acc.push({
        name: categoryName,
        value: asset.currentValue,
        color: getCategoryColor(asset.category?.type || 'other')
      });
    }
    return acc;
  }, [] as Array<{ name: string; value: number; color: string }>) || [];

  function getCategoryColor(type: string): string {
    const colors = {
      stocks: '#3B82F6',
      crypto: '#F59E0B', 
      commodities: '#EAB308',
      etf: '#8B5CF6',
      funds: '#10B981',
      other: '#6B7280'
    };
    return colors[type as keyof typeof colors] || colors.other;
  }

  // Mock performance data for different periods
  const performanceData = {
    weekly: [
      { period: 'Pzt', portfolio: 450000, benchmark: 448000 },
      { period: 'Sal', portfolio: 465000, benchmark: 452000 },
      { period: 'Çar', portfolio: 452000, benchmark: 455000 },
      { period: 'Per', portfolio: 478000, benchmark: 465000 },
      { period: 'Cum', portfolio: 475000, benchmark: 470000 },
      { period: 'Cmt', portfolio: 485000, benchmark: 478000 },
      { period: 'Paz', portfolio: 487642, benchmark: 481000 },
    ],
    monthly: [
      { period: 'Oca', portfolio: 380000, benchmark: 375000 },
      { period: 'Şub', portfolio: 405000, benchmark: 398000 },
      { period: 'Mar', portfolio: 425000, benchmark: 415000 },
      { period: 'Nis', portfolio: 445000, benchmark: 435000 },
      { period: 'May', portfolio: 465000, benchmark: 452000 },
      { period: 'Haz', portfolio: 487642, benchmark: 471000 },
    ],
    yearly: [
      { period: '2021', portfolio: 280000, benchmark: 275000 },
      { period: '2022', portfolio: 320000, benchmark: 305000 },
      { period: '2023', portfolio: 385000, benchmark: 370000 },
      { period: '2024', portfolio: 487642, benchmark: 465000 },
    ]
  };

  const currentPerformanceData = performanceData[selectedPeriod as keyof typeof performanceData];

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-card border-b border-border px-4 py-3 flex items-center justify-between">
        <h1 className="text-lg font-semibold">Raporlar</h1>
        <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
          <SelectTrigger className="w-32" data-testid="period-selector">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="weekly">Haftalık</SelectItem>
            <SelectItem value="monthly">Aylık</SelectItem>
            <SelectItem value="yearly">Yıllık</SelectItem>
          </SelectContent>
        </Select>
      </header>

      <main className="p-4">
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview" data-testid="tab-overview">Genel Bakış</TabsTrigger>
            <TabsTrigger value="performance" data-testid="tab-performance">Performans</TabsTrigger>
            <TabsTrigger value="income" data-testid="tab-income">Gelir/Gider</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-4">
            {/* Key Metrics */}
            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm text-muted-foreground">Toplam Getiri</CardTitle>
                </CardHeader>
                <CardContent>
                  <p 
                    className="text-xl font-bold"
                    style={{ 
                      color: (portfolioData?.summary.totalProfitLossPercent || 0) >= 0 
                        ? 'hsl(142.1 76.2% 36.3%)' 
                        : 'hsl(0 84.2% 60.2%)' 
                    }}
                    data-testid="total-return"
                  >
                    {(portfolioData?.summary.totalProfitLossPercent || 0).toFixed(2)}%
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm text-muted-foreground">Portföy Çeşitliliği</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-xl font-bold" data-testid="portfolio-diversity">
                    {categoryData.length}
                  </p>
                  <p className="text-xs text-muted-foreground">Kategori</p>
                </CardContent>
              </Card>
            </div>

            {/* Portfolio Allocation Pie Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Portföy Dağılımı</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64" data-testid="allocation-chart">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={categoryData}
                        cx="50%"
                        cy="50%"
                        innerRadius={40}
                        outerRadius={80}
                        paddingAngle={2}
                        dataKey="value"
                      >
                        {categoryData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip 
                        formatter={(value: number) => formatCurrency(value)}
                        labelFormatter={(label) => `${label}`}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                
                <div className="grid grid-cols-2 gap-2 mt-4">
                  {categoryData.map((category, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <div 
                        className="w-3 h-3 rounded-full" 
                        style={{ backgroundColor: category.color }}
                      />
                      <span className="text-xs text-muted-foreground">
                        {category.name}
                      </span>
                      <span className="text-xs font-medium ml-auto">
                        {portfolioData?.summary.totalValue 
                          ? ((category.value / portfolioData.summary.totalValue) * 100).toFixed(1)
                          : 0}%
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Top Performers */}
            <Card>
              <CardHeader>
                <CardTitle>En İyi Performans Gösteren Varlıklar</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {portfolioData?.assets
                    .filter(asset => asset.profitLossPercent > 0)
                    .sort((a, b) => b.profitLossPercent - a.profitLossPercent)
                    .slice(0, 5)
                    .map((asset, index) => (
                      <div key={asset.id} className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">
                            {index + 1}
                          </span>
                          <div>
                            <p className="font-medium text-sm">{asset.asset.symbol}</p>
                            <p className="text-xs text-muted-foreground">{asset.asset.name}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p 
                            className="text-sm font-semibold"
                            style={{ color: 'hsl(142.1 76.2% 36.3%)' }}
                          >
                            +{asset.profitLossPercent.toFixed(2)}%
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {formatCurrency(asset.profitLoss)}
                          </p>
                        </div>
                      </div>
                    )) || []}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="performance" className="space-y-4">
            {/* Performance Comparison Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Portföy vs Piyasa Performansı</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64" data-testid="performance-chart">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={currentPerformanceData}>
                      <defs>
                        <linearGradient id="portfolioGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="hsl(142.1 76.2% 36.3%)" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="hsl(142.1 76.2% 36.3%)" stopOpacity={0}/>
                        </linearGradient>
                        <linearGradient id="benchmarkGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="hsl(203.8863 88.2845% 53.1373%)" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="hsl(203.8863 88.2845% 53.1373%)" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <XAxis 
                        dataKey="period" 
                        axisLine={false}
                        tickLine={false}
                        tick={{ fontSize: 12, fill: 'hsl(215.4 16.3% 46.9%)' }}
                      />
                      <YAxis hide />
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(214.3 31.8% 91.4%)" />
                      <Tooltip 
                        formatter={(value: number, name: string) => [
                          formatCurrency(value), 
                          name === 'portfolio' ? 'Portföy' : 'Piyasa'
                        ]}
                      />
                      <Area
                        type="monotone"
                        dataKey="portfolio"
                        stroke="hsl(142.1 76.2% 36.3%)"
                        strokeWidth={2}
                        fill="url(#portfolioGradient)"
                      />
                      <Area
                        type="monotone"
                        dataKey="benchmark"
                        stroke="hsl(203.8863 88.2845% 53.1373%)"
                        strokeWidth={2}
                        fill="url(#benchmarkGradient)"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
                
                <div className="flex items-center justify-center space-x-6 mt-4">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-success rounded-full" />
                    <span className="text-xs text-muted-foreground">Portföyüm</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: 'hsl(203.8863 88.2845% 53.1373%)' }} />
                    <span className="text-xs text-muted-foreground">Piyasa Ortalaması</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Risk Metrics */}
            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm text-muted-foreground">Volatilite</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-xl font-bold" data-testid="volatility">
                    12.4%
                  </p>
                  <p className="text-xs text-muted-foreground">Standart Sapma</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm text-muted-foreground">Sharpe Oranı</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-xl font-bold" data-testid="sharpe-ratio">
                    1.85
                  </p>
                  <p className="text-xs text-muted-foreground">Risk-Getiri</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="income" className="space-y-4">
            {/* Income vs Expenses Summary */}
            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm text-muted-foreground">Bu Ay Gelir</CardTitle>
                </CardHeader>
                <CardContent>
                  <p 
                    className="text-xl font-bold"
                    style={{ color: 'hsl(142.1 76.2% 36.3%)' }}
                    data-testid="monthly-income"
                  >
                    {formatCurrency(incomeExpenseSummary.totalIncome)}
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm text-muted-foreground">Bu Ay Gider</CardTitle>
                </CardHeader>
                <CardContent>
                  <p 
                    className="text-xl font-bold"
                    style={{ color: 'hsl(0 84.2% 60.2%)' }}
                    data-testid="monthly-expenses"
                  >
                    {formatCurrency(incomeExpenseSummary.totalExpenses)}
                  </p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-muted-foreground">Net Gelir</CardTitle>
              </CardHeader>
              <CardContent>
                <p 
                  className="text-2xl font-bold"
                  style={{ 
                    color: incomeExpenseSummary.netIncome >= 0 
                      ? 'hsl(142.1 76.2% 36.3%)' 
                      : 'hsl(0 84.2% 60.2%)' 
                  }}
                  data-testid="net-income"
                >
                  {formatCurrency(incomeExpenseSummary.netIncome)}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {incomeExpenseSummary.netIncome >= 0 ? 'Fazla' : 'Açık'}
                </p>
              </CardContent>
            </Card>

            {/* Income Categories */}
            <Card>
              <CardHeader>
                <CardTitle>Gelir Dağılımı</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <i className="fas fa-money-bill-wave text-blue-600 text-sm" />
                      </div>
                      <span className="font-medium">Maaş</span>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold">{formatCurrency(18000)}</p>
                      <p className="text-xs text-muted-foreground">73.5%</p>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                        <i className="fas fa-percentage text-purple-600 text-sm" />
                      </div>
                      <span className="font-medium">Temettü</span>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold">{formatCurrency(6500)}</p>
                      <p className="text-xs text-muted-foreground">26.5%</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Export Options */}
            <Card>
              <CardHeader>
                <CardTitle>Rapor Dışa Aktarma</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    data-testid="export-pdf"
                  >
                    <i className="fas fa-file-pdf text-red-600 mr-3" />
                    PDF Raporu İndir
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    data-testid="export-excel"
                  >
                    <i className="fas fa-file-excel text-green-600 mr-3" />
                    Excel Tablosu İndir
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
