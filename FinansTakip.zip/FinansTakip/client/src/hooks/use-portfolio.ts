import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { PortfolioSummary, PortfolioAssetWithDetails } from "@/types/portfolio";

interface PortfolioData {
  summary: PortfolioSummary;
  assets: PortfolioAssetWithDetails[];
}

export function usePortfolio() {
  return useQuery<PortfolioData>({
    queryKey: ["/api/portfolio"],
  });
}

export function useAddPortfolioAsset() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (data: {
      assetId: string;
      quantity: string;
      averagePurchasePrice: string;
      purchaseCurrency?: string;
      totalInvested: string;
      purchaseDate?: string;
      exchangeRate?: string;
    }) => {
      const response = await apiRequest("POST", "/api/portfolio/assets", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/portfolio"] });
    },
  });
}

export function useAddTransaction() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (data: {
      assetId: string;
      type: "buy" | "sell";
      quantity: string;
      price: string;
      totalAmount: string;
      fees?: string;
      currency: string;
      date: Date;
    }) => {
      const response = await apiRequest("POST", "/api/transactions", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/portfolio"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
    },
  });
}
