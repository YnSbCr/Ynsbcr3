import { useQuery, useMutation } from "@tanstack/react-query";
import type { Asset, AssetCategory } from "@shared/schema";
import type { AssetSearchResult, AssetPrice } from "@/types/portfolio";

export function useAssetCategories() {
  return useQuery<AssetCategory[]>({
    queryKey: ["/api/asset-categories"],
  });
}

export function useAssets(categoryId?: string) {
  return useQuery<Asset[]>({
    queryKey: categoryId ? ["/api/assets", { categoryId }] : ["/api/assets"],
  });
}

export function useAssetSearch(query: string) {
  return useQuery<AssetSearchResult[]>({
    queryKey: ["/api/assets/search", query],
    queryFn: async () => {
      if (!query || query.length <= 1) return [];
      const response = await fetch(`/api/assets/search?q=${encodeURIComponent(query)}`);
      if (!response.ok) throw new Error('Search failed');
      return response.json();
    },
    enabled: query.length > 1,
  });
}

export function useAssetPrice(symbol: string) {
  return useQuery<AssetPrice>({
    queryKey: ["/api/assets", symbol, "price"],
    refetchInterval: 60000, // Refetch every minute
  });
}
