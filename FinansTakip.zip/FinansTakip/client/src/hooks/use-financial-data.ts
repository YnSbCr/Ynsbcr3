import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { IncomeRecord, ExpenseRecord } from "@shared/schema";
import type { IncomeExpenseSummary } from "@/types/portfolio";

export function useIncomeRecords() {
  return useQuery<IncomeRecord[]>({
    queryKey: ["/api/income"],
  });
}

export function useExpenseRecords() {
  return useQuery<ExpenseRecord[]>({
    queryKey: ["/api/expenses"],
  });
}

export function useAddIncomeRecord() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (data: {
      type: string;
      amount: string;
      currency: string;
      description?: string;
      date: Date;
      isRecurring?: boolean;
    }) => {
      const response = await apiRequest("POST", "/api/income", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/income"] });
    },
  });
}

export function useAddExpenseRecord() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (data: {
      type: string;
      amount: string;
      currency: string;
      description?: string;
      interestRate?: string;
      installments?: number;
      dueDate?: Date;
      date: Date;
      isRecurring?: boolean;
    }) => {
      const response = await apiRequest("POST", "/api/expenses", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/expenses"] });
    },
  });
}

export function useIncomeExpenseSummary() {
  const { data: incomeRecords } = useIncomeRecords();
  const { data: expenseRecords } = useExpenseRecords();

  // Calculate current month summary
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();

  const thisMonthIncome = incomeRecords?.filter(record => {
    const recordDate = new Date(record.date);
    return recordDate.getMonth() === currentMonth && recordDate.getFullYear() === currentYear;
  }).reduce((sum, record) => sum + parseFloat(record.amount), 0) || 0;

  const thisMonthExpenses = expenseRecords?.filter(record => {
    const recordDate = new Date(record.date);
    return recordDate.getMonth() === currentMonth && recordDate.getFullYear() === currentYear;
  }).reduce((sum, record) => sum + parseFloat(record.amount), 0) || 0;

  return {
    totalIncome: thisMonthIncome,
    totalExpenses: thisMonthExpenses,
    netIncome: thisMonthIncome - thisMonthExpenses,
    currency: "TRY"
  } as IncomeExpenseSummary;
}
